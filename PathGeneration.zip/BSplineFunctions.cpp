#include <gl/glew.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include <gl/freeglut.h>
#include <stdio.h>
#include <stdlib.h>
#include "BSplineFunctions.h"
#include "PathGeneration.h"
#include <algorithm>
#include "DrawCurves.h"
#include <math.h>

const long double pi = 3.141592653589793238L;

void FindKnotParameters(float *KnotVector, int p, int n, float uhat, int r, int *KnotParameters)
{
	int k = 0, s = 0, new_r = 0;
	// Results are stored in KnotParameters: [1] = k, [2] = s, [3] = r.
	// Find where uhat lies in knot vector, determine k
	for (int i = 0; i < n + p + 1; i++)
	{	// if uhat is >= u(i) and < u(i+1), then k = i
		if ((uhat >= *(KnotVector + i)) && (uhat < *(KnotVector + i + 1)))
		{
			k = i;
			break;
		}
	}

	if (!k) // This means k is the last index in the knot vector
	{
		k = n + p + 1 - 1;
		printf("%d\r\n", k);
	}
	// Determine multiplicity s given k
	for (int j = k; j >= 0; j--)
	{
		if (uhat == *(KnotVector + j) )
		{
			s++;
		}
		else
		{
			break;
		}
	}

	// If multiplicity is bigger than degree, can't insert any knots!
	if (s >= p)
	{
		return;
	}

	// Check if r + s <= p
	if (r + s > p)
	{
		new_r = p - s;
		//printf("Since r + s must be less than or equal to p, so r can't be %d when s = %d, and p = %d,", r,s,p);
		//printf("new r is %d\r\n", new_r);
	}
	else
	{
		new_r = r;
		//printf("r: %d\r\n", new_r);
	}

	*KnotParameters = k;
	*(KnotParameters + 1) = s;
	*(KnotParameters + 2) = new_r;
}


int CurveKnotIns(int np, int p, float * UP, float * Pw, float u, int k, int s, int r, float * UQ, float * Qw)
{
	int mp = np + p + 1, L, nq = np + r;
	float Rw[50][2];
	clear_big_mat(50,2, Rw[0]);

	// Load new knot vector
	for (int i = 0; i <= k; i++)
	{
		*(UQ + i) = *(UP + i);
	}

	for (int i = 1; i <= r; i++)
	{
		*(UQ + k + i) = u;
	}

	for (int i = k + 1; i <= mp; i++)
	{
		*(UQ + i + r) = *(UP + i);
	}

	// Save unaltered control point
	for (int i = 0; i <= k - p; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			*(Qw + (i*2) + j) = *(Pw + (i*2) + j);
		}	
	}

	for (int i = k - s; i <= np; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			*(Qw + ((i + r)*2) + j) = *(Pw + (i*2) + j);
		}
		
	}

	for (int i = 0; i <= p - s; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			Rw[i][j] = *(Pw + (k - p + i)*2 + j);
		}
		
	}

	// Insert the knot r times
	for (int j = 1; j <= r; j++)
	{
		L = k - p + j;

		for (int i = 0; i <= p - j - s; i++)
		{
			float alpha = (u - *(UP + L + i)) / (*(UP + i + k + 1) - *(UP + L + i));
			for (int h = 0; h < 2; h++)
			{
				Rw[i][h] = alpha*Rw[i + 1][h] + (1.0 - alpha)*Rw[i][h];
			}
		}

		for (int q = 0; q < 2; q++)
		{
			*(Qw + L*2 + q) = Rw[0][q];
			*(Qw + (k + r - j - s)*2 + q) = Rw[p - j - s][q];
		}
	}

	// Load remaining control points
	for (int i = L + 1; i < k - s; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			*(Qw + 2*i + j) = Rw[i - L][j];
		}
	}

	return nq;
}


int findSpan(int number_of_control_points, int degree, float u, float *knot_vector)
{
	int low, high, mid;

	if ( u == *(knot_vector + (number_of_control_points + 1)) )
	{
		return number_of_control_points;
	}

	low = degree;
	high = number_of_control_points + 1;
	mid = (low + high) / 2;

	while ( (u < *(knot_vector + mid)) || (u >= *(knot_vector + mid + 1)) )
	{
		//printf("HERE U\r\n");
		if ( u < *(knot_vector + mid) )
		{
			high = mid;
		}
		else
		{
			low = mid;
		}
		mid = (low + high) / 2;
	}

	return mid;
}


void BasisFunctions(int index, float u, int degree, float * knot_vector, float * N)
{
	float left[20], right[20], saved, temp; 
	clear_mat(20, left);
	clear_mat(20, right);
	*N = 1.0;

	for (int j = 1; j <= degree; j++)
	{
		left[j] = u - *(knot_vector + index + 1 - j);
		right[j] = *(knot_vector + index + j) - u;
		saved = 0.0;

		for (int r = 0; r < j; r++)
		{
			temp = *(N + r) / (right[r + 1] + left[j - r]);
			*(N + r) = saved + right[r + 1] * temp;
			saved = left[j - r] * temp;
		}
		*(N + j) = saved;
	}
}

// Algorithm A3.3
void CurveDerivCpts(int p, float *U, float *P, int d, int r1, int r2, output PK_struct[3][100])
{
	int r = r2 - r1;

	for (int i = 0; i <= r; i++)
	{
		PK_struct[0][i].PK[0] = *(P + (r1 + i) * 2 + 0);
		PK_struct[0][i].PK[1] = *(P + (r1 + i) * 2 + 1);
	}

	for (int k = 1; k <= d; k++)
	{
		int tmp = p - k + 1;

		for (int i = 0; i <= r - k; i++)
		{
			PK_struct[k][i].PK[0] = (float)tmp * (PK_struct[k - 1][i + 1].PK[0] - PK_struct[k - 1][i].PK[0]) / (*(U + r1 + i + p + 1) - *(U + r1 + i + k));
			PK_struct[k][i].PK[1] = (float)tmp * (PK_struct[k - 1][i + 1].PK[1] - PK_struct[k - 1][i].PK[1]) / (*(U + r1 + i + p + 1) - *(U + r1 + i + k));
		}
	}
}


void AllBasisFuns(int span, float u, int p, float* U, float *N, float* N_new, int col_N_new)
{
	for (int i = 0; i <= p; i++)
	{
		BasisFunctions(span, u, i, U, N);
		for (int j = 0; j <= i; j++)
		{
			*(N_new + j*col_N_new + i) = *(N+j);
		}
	}
}


// Algorithm A3.4
void CurveDerivsAlg2(int n, int p, float* U, float *P, float u, int d, float* CK, output PK_struct[3][100])
{
	float N_new[40][4], N[40];
	clear_mat(40, N);
	clear_big_mat(40, 4, N_new[0]);
	int du = min(d, p);

	for (int k = p + 1; k <= d; k++)
	{
		*(CK + k * 2 + 0) = 0.0;
		*(CK + k * 2 + 1) = 0.0;
	}
	
	int span = findSpan(n-1, p, u, U);
	AllBasisFuns(span, u, p, U, N, N_new[0], 4);
	CurveDerivCpts(p, U, P, du, span - p, span, PK_struct);

	for (int k = 0; k <= du; k++)
	{
		*(CK + k * 2 + 0) = 0.0;
		*(CK + k * 2 + 1) = 0.0;
		for (int j = 0; j <= p - k; j++)
		{
			*(CK + k * 2 + 0) += N_new[j][p - k] * PK_struct[k][j].PK[0];
			*(CK + k * 2 + 1) += N_new[j][p - k] * PK_struct[k][j].PK[1];
		}
	}
}


void BSplineCurve(int number_of_control_points, int skip_number, int degree, float * knot_vector, float * control_points, float u, float * CurvePoints)
{
	int span, col = 2;
	float N[100], Cx = 0.0, Cy = 0.0;

	clear_mat(100, N);
	span = findSpan(number_of_control_points, degree, u, knot_vector);
	BasisFunctions(span, u, degree, knot_vector, N);

	for (int i = 0; i <= degree; i++)
	{
		Cx += N[i] * (*(control_points + (span - degree + i + skip_number)*col ));
		Cy += N[i] * (*(control_points + (span - degree + i + skip_number)*col + 1));
	}
	*CurvePoints = Cx;
	*(CurvePoints + 1) = Cy;
}


void calculate_uniform_knot_vector(int number_of_knots, int degree, float * knot_vector)
{
	int number_of_interior_knots = (number_of_knots + 1) - 2 * (degree + 1); // m = p + k + 1
	float knot_value = 0.0;

	for (int i = 0; i < (number_of_knots + 1) - (degree + 1); i++)
	{
		if (i > degree)
		{
			knot_value += 1.0 / ((float)number_of_interior_knots + 1.0);
			*(knot_vector + i) = knot_value;
		}
		else
		{
			*(knot_vector + i) = 0.0;
			*(knot_vector + (number_of_knots) - i) = 1.0;
		}
	}
}


int InsertNewKnot(int degree, int number_of_control_points, float uhat, int r, float *knot_vector, float *knot_vector_new, float *P, float *Q)
{
	int KnotParameters[3] = { 0,0,0 }, number_of_new_control_points;

	FindKnotParameters(knot_vector, degree, number_of_control_points, uhat, r, KnotParameters);
	number_of_new_control_points = CurveKnotIns(number_of_control_points, degree, knot_vector,P, uhat, KnotParameters[0], KnotParameters[1], KnotParameters[2], knot_vector_new, Q);

	for (int i = 0; i < GetNumberOfKnots() + KnotParameters[2] + 1; i++)
	{
		knot_vector[i] = knot_vector_new[i]; // Update knot vector when the new inserted knot
	}

	for (int i = 0; i < number_of_new_control_points; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			*(P + i*2 + j) = *(Q + i * 2 + j); // Update control points
		}
	}

	return number_of_new_control_points;
}


void clear_mat(int length, float * mat)
{
	for (int i = 0; i < length; i++)
	{
		*(mat + i) = 0.0;	
	}
}


void clear_big_mat(int row, int col, float * mat)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			*(mat + i*col + j) = 0.0;
		}
	}
}