#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

using namespace std;

typedef struct
{
	float PK[2];

}output;

int findSpan(int number_of_control_points, int degree, float u, float *knot_vector);

void BasisFunctions(int index, float u, int degree, float * knot_vector, float * N);

void BSplineCurve(int number_of_control_points, int skip_number, int degree, float * knot_vector, float * control_points, float u, float * CurvePoints);

void clear_mat(int length, float * mat);

void clear_big_mat(int row, int col, float * mat);

void calculate_uniform_knot_vector(int number_of_knots, int degree, float * knot_vector);

int CurveKnotIns(int np, int p, float * UP, float * Pw, float u, int k, int s, int r, float * UQ, float * Qw);

void FindKnotParameters(float *KnotVector, int p, int n, float uhat, int r, int *KnotParameters);

void AllBasisFuns(int span, float u, int p, float* U, float* N, float* N_new, int col_N_new);

void CurveDerivCpts(int p, float *U, float *P, int d, int r1, int r2, output PK_struct[3][100]);

void CurveDerivsAlg2(int n, int p, float* U, float *P, float u, int d, float* CK, output PK_struct[3][100]);

void deCasteljau1(float *P, int n, float u, float *C);

int InsertNewKnot(int degree, int number_of_control_points, float uhat, int r, float *knot_vector, float *knot_vector_new, float *P, float *Q);