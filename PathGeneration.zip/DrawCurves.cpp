#include <gl/glew.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include <gl/freeglut.h>
#include "DrawCurves.h"
#include "BSplinefunctions.h"
#include "PathGeneration.h"
#include <math.h>

int col = 2;
static float knot_vector_new[100];
static int mknots = 0;

int colMap = 10;
int arc_interval = 50;
const long double pi = 3.141592653589793238L;
output PK_struct[3][100];
output output_struct[3][1000];

void DrawVehicle(float VehicleCenterX, float VehicleCenterY, float VehicleOrientation, float VehicleWidth, float VehicleLength)
{
	glColor3f(1.0f, 0.0f, 1.0f);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();

	glTranslatef(VehicleCenterX, VehicleCenterY, 0.0);
	glRotatef(180.0*VehicleOrientation/pi, 0.0, 0.0, 1.0);

	glBegin(GL_QUADS);
	glVertex2f((GLdouble)(-1.0*VehicleLength/2.0), (GLdouble)(VehicleWidth/2.0));
	glVertex2f((GLdouble)(1.0*VehicleLength / 2.0), (GLdouble)(VehicleWidth / 2.0));
	glVertex2f((GLdouble)(1.0*VehicleLength / 2.0), (GLdouble)(-1.0*VehicleWidth / 2.0));
	glVertex2f((GLdouble)(-1.0*VehicleLength / 2.0), (GLdouble)(-1.0*VehicleWidth / 2.0));
	glEnd();

	glPopMatrix();
}

void DrawEditControlPointCircle(float rx, float ry)
{
	float x, y, radius = 6.0;
	int interval = 20;

	glColor3f(1.0f, 0.25f, 0.0f);
	glLineWidth(1.0);
	glLineStipple(1, 0xAAAA);
	glEnable(GL_LINE_STIPPLE);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < interval; i++)
	{
		x = rx + radius*cos(2.0*pi*((float)i / (float)(interval - 1)));
		y = ry + radius*sin(2.0*pi*((float)i / (float)(interval - 1)));
		glVertex2f((GLdouble)x, (GLdouble)y);
	}
	glEnd();
	glFlush();
	glDisable(GL_LINE_STIPPLE);
}

void DrawTangentLines(float u, float Cx, float Cy, float dCx, float dCy, float scale)
{
	float P[2][2], dx, dy, Nx1, Ny1, Nx1_new, Ny1_new, Nx2_new, Ny2_new, Tangent[2], Normal[2][2];

	FindNormalAndTangent(Cx,Cy,dCx,dCy, Tangent, Normal[0], scale);

	P[0][0] = Cx;
	P[0][1] = Cy;

	P[1][0] = Tangent[0];
	P[1][1] = Tangent[1];

	// Draw Tangent Vector
	glColor3f(1.0f, 0.5f, 0.0f);
	glLineWidth(1.0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < 2; i++)
	{
		glVertex2f((GLdouble)(P[i][0]), (GLdouble)(P[i][1]));
	}
	glEnd();
	glFlush();
	glDisable(GL_LINE_STIPPLE);

	// Draw Normal Vector
	P[1][0] = Normal[0][0];
	P[1][1] = Normal[0][1];

	glColor3f(0.0f, 1.0f, 0.0f);
	glLineWidth(2.0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < 2; i++)
	{
		glVertex2f((GLdouble)(P[i][0]), (GLdouble)(P[i][1]));
	}
	glEnd();
	glFlush();
	glDisable(GL_LINE_STIPPLE);

	// Draw Normal Vector in opposite direction
	P[1][0] = Normal[1][0];
	P[1][1] = Normal[1][1];
	glColor3f(0.0f, 1.0f, 0.0f);
	glLineWidth(2.0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < 2; i++)
	{
		glVertex2f((GLdouble)(P[i][0]), (GLdouble)(P[i][1]));
	}
	glEnd();
	glFlush();
	glDisable(GL_LINE_STIPPLE);
}

void DrawFailedKnots(float px, float py, int *constraint_info)
{
	if (!*(constraint_info)) // Up constraint not met
	{
		glColor3f(160.0f/255.0f, 32.0f / 255.0f, 240.0f / 255.0f);
	}
	else
	{
		glColor3f(0.0f, 0.0f, 0.0f); // Down constraint not met
	}
	
	glPointSize(3.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < 1; i++)
	{
		glVertex2f((GLdouble)px, (GLdouble)py);
	}
	glEnd();
	glFlush();

}

void DrawOutOfMapPoints(float Px, float Py)
{
	glPointSize(3.0);
	glColor3f(0.0f, 0.0f, 1.0f);
	glBegin(GL_POINTS);
	glVertex2f((GLdouble)Px, (GLdouble)Py);
	glEnd();
	glFlush();
}

void DrawMapPoints(int number_of_points, float *P)
{
	glPointSize(5.0);
	glColor3f(0.0f, 0.0f, 0.0f);
	glBegin(GL_POINTS);
	for (int i = 0; i < number_of_points; i++)
	{
		glVertex2f((GLdouble)(*(P + i*colMap + 0)), (GLdouble)(*(P + i*colMap + 1)));
	}
	glEnd();
	glFlush();
}

void DrawMapLines(int number_of_points, float *P)
{
	glColor3f(0.0f, 0.0f, 1.0f);
	glLineWidth(2.0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < number_of_points; i++)
	{
		if (!(*(P + (i*colMap) + 3))) // straight line
		{
			glVertex2f((GLdouble)(*(P + i*colMap + 0)), (GLdouble)(*(P + i*colMap + 1)));
		}
		else // circular arc
		{
			DrawMapArc(*(P + i*colMap + 4), *(P + i*colMap + 5), *(P + i*colMap + 6), *(P + i*colMap + 7), *(P + i*colMap + 8), *(P + i*colMap + 9));
		}
	}
	glEnd();
	glFlush();
	glDisable(GL_LINE_STIPPLE);
}

void DrawPath(int number_of_points, float *P, float *Phat)
{
	glColor3f(131.0f/ 255.0f, 139.0f / 255.0f, 131.0f / 255.0f);
	for (int i = 0; i < number_of_points-1; i++)
	{
		if (!(*(P + (i*colMap) + 3))) // straight line
		{
			glBegin(GL_QUADS);
			glVertex2f((GLdouble)(*(P + i*colMap + 0)), (GLdouble)(*(P + i*colMap + 1)));
			glVertex2f((GLdouble)(*(P + (i+1)*colMap + 0)), (GLdouble)(*(P + (i+1)*colMap + 1)));
			glVertex2f((GLdouble)(*(Phat + (i + 1)*colMap + 0)), (GLdouble)(*(Phat + (i + 1)*colMap + 1)));
			glVertex2f((GLdouble)(*(Phat + i*colMap + 0)), (GLdouble)(*(Phat + i*colMap + 1)));
			glEnd();
		}
		else // circular arc
		{
			int counterclockwise_rotation = *(P + i*colMap + 9);
			float rx = *(P + i*colMap + 4), ry = *(P + i*colMap + 5), rxhat = *(P + i*colMap + 4), ryhat = *(P + i*colMap + 5);
			float radius = *(P + i*colMap + 6), radiushat = *(Phat + i*colMap + 6);
			float theta1 = *(P + i*colMap + 7), theta2 = *(P + i*colMap + 8), thetahat1 = *(Phat + i*colMap + 7), thetahat2 = *(Phat + i*colMap + 8);
			float theta_interval = fabs(theta1 - theta2);
			float theta_interval_hat = fabs(thetahat1 - thetahat2);
			float x1, x2, xhat1, xhat2, y1, y2, yhat1, yhat2;

			if (!counterclockwise_rotation)
			{
				theta_interval = 2 * pi - theta_interval;
				theta_interval_hat = 2 * pi - theta_interval_hat;
			}

			theta_interval = theta_interval / (float)arc_interval;
			theta_interval_hat = theta_interval_hat / (float)arc_interval;

			glBegin(GL_QUADS);
			for (int k = 0; k < arc_interval; k++)
			{
				if (counterclockwise_rotation)
				{
					x1 = rx + radius*cos(theta1 + (float)k*theta_interval);
					y1 = ry + radius*sin(theta1 + (float)k*theta_interval);
					x2 = rx + radius*cos(theta1 + (float)(k+1)*theta_interval);
					y2 = ry + radius*sin(theta1 + (float)(k+1)*theta_interval);
					xhat1 = rxhat + radiushat*cos(thetahat1 + (float)(k+1)*theta_interval_hat);
					yhat1 = ryhat + radiushat*sin(thetahat1 + (float)(k+1)*theta_interval_hat);
					xhat2 = rxhat + radiushat*cos(thetahat1 + (float)k*theta_interval_hat);
					yhat2 = ryhat + radiushat*sin(thetahat1 + (float)k*theta_interval_hat);
				}
				else
				{
					x1 = rx + radius*cos(theta1 - (float)k*theta_interval);
					y1 = ry + radius*sin(theta1 - (float)k*theta_interval);
					x2 = rx + radius*cos(theta1 - (float)(k + 1)*theta_interval);
					y2 = ry + radius*sin(theta1 - (float)(k + 1)*theta_interval);
					xhat1 = rxhat + radiushat*cos(thetahat1 - (float)(k + 1)*theta_interval_hat);
					yhat1 = ryhat + radiushat*sin(thetahat1 - (float)(k + 1)*theta_interval_hat);
					xhat2 = rxhat + radiushat*cos(thetahat1 - (float)k*theta_interval_hat);
					yhat2 = ryhat + radiushat*sin(thetahat1 - (float)k*theta_interval_hat);
				}

				glVertex2f((GLdouble)x1, (GLdouble)y1);
				glVertex2f((GLdouble)x2, (GLdouble)y2);
				glVertex2f((GLdouble)xhat1, (GLdouble)yhat1);
				glVertex2f((GLdouble)xhat2, (GLdouble)yhat2);
			}
			glEnd();
		}
	}
}

void DrawMapArc(float rx, float ry, float radius, float theta1, float theta2, int counterclockwise_rotation)
{
	float x, y, theta_interval = fabs(theta1 - theta2);

	if (!counterclockwise_rotation)
	{
		theta_interval = 2 * pi - theta_interval;
	}

	theta_interval = theta_interval / (float)arc_interval;

	for (int i = 0; i < arc_interval + 1; i++)
	{
		if (counterclockwise_rotation)
		{
			x = rx + radius*cos(theta1 + (float)i*theta_interval);
			y = ry + radius*sin(theta1 + (float)i*theta_interval);
		}
		else
		{
			x = rx + radius*cos(theta1 - (float)i*theta_interval);
			y = ry + radius*sin(theta1 - (float)i*theta_interval);
		}

		glVertex2f((GLdouble)x, (GLdouble)y);
	}

}

void DrawMapContour(int number_of_points, float *P)
{
	DrawMapLines(number_of_points, P);
}


void DrawControlPoints(int number_of_control_points, int skip_number, float screen_width, float screen_height, float *P)
{
	glPointSize(4.0);
	glColor3f(1.0f, 0.0f, 0.0f);
	glBegin(GL_POINTS);
	for (int i = 0; i < number_of_control_points; i++)
	{
		glVertex2f((GLdouble)(*(P + ((i + skip_number)*col) + 0)), (GLdouble)(*(P + ((i + skip_number)*col) + 1)));
	}
	glEnd();
	glFlush();
}

void DrawPolygon(int number_of_control_points, int skip_number, float screen_width, float screen_height, float *P)
{
	glColor3f(1.0f, 140.0f/255.0f, 0.0f);
	glLineWidth(1.0);
	glLineStipple(4, 0xAAAA);
	glEnable(GL_LINE_STIPPLE);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < number_of_control_points; i++)
	{
		glVertex2f((GLdouble)(*(P + ((i + skip_number)*col) + 0)), (GLdouble)(*(P + ((i + skip_number)*col) + 1) ));
	}
	glEnd();
	glFlush();
	glDisable(GL_LINE_STIPPLE);
}


void DrawBSplineCurve(int number_of_control_points, int skip_number, int degree, float screen_width, float screen_height, float *P, float *knot_vector, bool knot_inserted)
{
	float u, C[2], CK[3][2];
	int check_index = 1;
	const int interval = 1000; // For smoother curve, especially for the INSANE map, use bigger interval
	
	int number_of_knots = (number_of_control_points - 1) + degree + 1;
	//printf("HERE H\r\n");
	if (!knot_inserted) // If the curve does not have new knots inserted, then the knot vector is uniform and unchanged, else if there's a new knot inserted, the new knot vector is no longer uniform, stop this calculation, just append to original knot vector.
	{
		calculate_uniform_knot_vector(number_of_knots, degree, knot_vector);	
	}
	//printf("HERE I\r\n");
	glColor3f(0.0f, 1.0f, 0.0f);
	//clear_mat(100, knot_vector_new);
	mknots = number_of_knots;
	for (int j = 0; j < number_of_knots + 1; j++)
	{
		knot_vector_new[j] = *(knot_vector + j);
	}

	glLineWidth(2.0);
	
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < interval; i++)
	{
		//printf("HERE J\r\n");
		u = (float)i / (float)(interval-1);
		//BSplineCurve(number_of_control_points - 1, skip_number,degree, knot_vector, P, u, C); 
		CurveDerivsAlg2(number_of_control_points, degree, knot_vector, P, u, 2, CK[0], PK_struct);
		glVertex2f((GLdouble)(CK[0][0]), (GLdouble)(CK[0][1]));

		for (int j = 0; j < degree; j++)
		{
			for (int l = 0; l < 2; l++)
			{
				output_struct[j][i].PK[l] = CK[j][l];
			}
		}
	}
	glEnd();
	glFlush();
}

float *GetKnotVector()
{
	return knot_vector_new;
}

int GetNumberOfKnots()
{
	return mknots;
}
