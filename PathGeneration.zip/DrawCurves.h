void DrawControlPoints(int number_of_control_points, int skip_number, float screen_width, float screen_height, float *P);

void DrawPolygon(int number_of_control_points, int skip_number, float screen_width, float screen_height, float *P);

void DrawBSplineCurve(int number_of_control_points, int skip_number, int degree, float screen_width, float screen_height, float *P, float *knot_vector, bool knot_inserted);

float *GetKnotVector();

int GetNumberOfKnots();

void DrawMapPoints(int number_of_points, float *P);

void DrawMapLines(int number_of_points, float *P);

void DrawMapArc(float rx, float ry, float radius, float theta1, float theta2, int counterclockwise_rotation);

void DrawMapContour(int number_of_points, float *P);

void DrawTangentLines(float u, float Cx, float Cy, float dCx, float dCy, float scale);

void DrawFailedKnots(float px, float py, int *constraint_info);

void DrawEditControlPointCircle(float rx, float ry);

void DrawPath(int number_of_points, float *P, float *Phat);

void DrawOutOfMapPoints(float Px, float Py);

void DrawVehicle(float VehicleCenterX, float VehicleCenterY, float VehicleOrientation, float VehicleWidth, float VehicleLength);