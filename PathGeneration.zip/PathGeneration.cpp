#include <gl/glew.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include <gl/freeglut.h>
#include <stdio.h>
#include <stdlib.h>
#include "BSplineFunctions.h"
#include "PathGeneration.h"
#include <algorithm>
#include "DrawCurves.h"
#include <math.h>

const long double pi = 3.141592653589793238L;

void FindNormalAndTangent(float Cx, float Cy, float dCx, float dCy, float *Tangent, float *Normal, float scale)
{
	float dx, dy, Nx1, Ny1, Nx1_new, Ny1_new, Nx2_new, Ny2_new;

	// Normalized tangent vector with respect to the origin
	dx = dCx / Distance(dCx, dCy);
	dy = dCy / Distance(dCx, dCy);

	// Normal Vector
	Nx1 = cos(pi / 2.0)*dx - sin(pi / 2.0)*dy;
	Ny1 = sin(pi / 2.0)*dx + cos(pi / 2.0)*dy;

	// Normalized normal vector with respect to the origin
	Nx1_new = Nx1 / Distance(Nx1, Ny1);
	Ny1_new = Ny1 / Distance(Nx1, Ny1);

	// Normalized normal vector in opposite direction
	Nx2_new = -Nx1_new;
	Ny2_new = -Ny1_new;

	// Tangent vector transformed to the point on the curve at given knot
	*(Tangent) = Cx + scale*dx;
	*(Tangent + 1) = Cy + scale*dy;

	// Normal vector transformed to the point on the curve at given knot
	*(Normal + 0 * 2 + 0) = Cx + scale*Nx1_new;
	*(Normal + 0 * 2 + 1) = Cy + scale*Ny1_new;

	// Normal vector in opposite direction transformed to the point on the curve at given knot
	*(Normal + 1 * 2 + 0) = Cx + scale*Nx2_new;
	*(Normal + 1 * 2 + 1) = Cy + scale*Ny2_new;
}


void CheckCorridorConstraint(float *Normal, float Cx, float Cy, float corridor_constraint, int *constraint_info, float *P_fail)
{
	float Nx1 = (*(Normal + 0 * 2 + 0) - Cx) / corridor_constraint,  // Recover normal from origin for incremental scaling later
		Ny1 = (*(Normal + 0 * 2 + 1) - Cy) / corridor_constraint,
		Nx2 = (*(Normal + 1 * 2 + 0) - Cx) / corridor_constraint,
		Ny2 = (*(Normal + 1 * 2 + 1) - Cy) / corridor_constraint,
		NxUp, NyUp, NxDown, NyDown;

	int interval = 20;
	bool up_constraint_met = true, down_constraint_met = true;
	unsigned char pixelup, pixeldown;

	if (Ny1 < Ny2) // This determines normal direction
	{
		NxUp = Nx2;
		NyUp = Ny2;
		NxDown = Nx1;
		NyDown = Ny1;
	}
	else
	{
		NxUp = Nx1;
		NyUp = Ny1;
		NxDown = Nx2;
		NyDown = Ny2;
	}

	// scale normal vector and check for corridor constraint
	for (int i = 0; i < interval; i++)
	{
		if (up_constraint_met)
		{	// check if the allowable normal distance from current point along the normal direction is colliding with the corridor,
			// check the pixel, because it's cumbersome to use equations and such..
			float PxUp = Cx + NxUp * corridor_constraint*((float)i / (float)interval);
			float PyUp = Cy + NyUp * corridor_constraint*((float)i / (float)interval);
			glReadPixels((GLint)PxUp, (GLint)PyUp, 1, 1, GL_BLUE, GL_UNSIGNED_BYTE, &pixelup);
			if (pixelup == 255)
			{
				up_constraint_met = false;
				*(constraint_info) = 0;
				*(P_fail) = PxUp;
				*(P_fail + 1) = PyUp;
				break;
			}
		}

		if (down_constraint_met)
		{
			float PxDown = Cx + NxDown * corridor_constraint*((float)i / (float)interval);
			float PyDown = Cy + NyDown * corridor_constraint*((float)i / (float)interval);
			glReadPixels((GLint)PxDown, (GLint)PyDown, 1, 1, GL_BLUE, GL_UNSIGNED_BYTE, &pixeldown);
			if (pixeldown == 255)
			{
				down_constraint_met = false;
				*(constraint_info + 1) = 0;
				*(P_fail) = PxDown;
				*(P_fail + 1) = PyDown;
				break;
			}
		}
	}
}


void ReadPathPixel(float Cx, float Cy, unsigned char *pixelpath, float offset)
{
	// Evaluate the adjacent pixels of the current point on the curve . 
	glReadPixels((GLint)(Cx + offset), (GLint)(Cy), 1, 1, GL_GREEN, GL_UNSIGNED_BYTE, pixelpath);
	glReadPixels((GLint)(Cx - offset), (GLint)(Cy), 1, 1, GL_GREEN, GL_UNSIGNED_BYTE, pixelpath + 1);
	glReadPixels((GLint)(Cx), (GLint)(Cy + offset), 1, 1, GL_GREEN, GL_UNSIGNED_BYTE, pixelpath + 2);
	glReadPixels((GLint)(Cx), (GLint)(Cy - offset), 1, 1, GL_GREEN, GL_UNSIGNED_BYTE, pixelpath + 3);
}


float Distance(float dx, float dy)
{
	return sqrt(pow(dx, 2.0) + pow(dy, 2.0));
}


bool AdjustControlPointForLine(int indexhat, int indexhat_new, float *P, float Px_mid, float Py_mid)
{
	// For straight path cases: find the distance between the point outside of the segment and the indexhat+1th and indexhat-1th control points, move in the direction that is closest to the ith control point 
	int division = 10;
	float Tx, Ty;

	Tx = (*(P + (indexhat_new)* 2 + 0) - Px_mid) * (float)(9) / (float)division; // move a fraction of the distance in that direction
	Ty = (*(P + (indexhat_new)* 2 + 1) - Py_mid) * (float)(9) / (float)division;
	*(P + (indexhat)* 2 + 0) = Px_mid + Tx;
	*(P + (indexhat)* 2 + 1) = Py_mid + Ty;

	return false;
}


int find_quadrant(float theta)
{
	int quadrant;
	if (theta > 0 && theta < pi / 2.0)
	{
		quadrant = 0;
	}
	else if (theta < pi && theta > pi / 2.0)
	{
		quadrant = 1;
	}
	else if (theta > -pi && theta < -pi / 2.0)
	{
		quadrant = 2;
	}
	else if (theta < 0 && theta > -pi / 2.0)
	{
		quadrant = 3;
	}
	return quadrant;
}


float find_rotation_direction(int indexhat_new, float *P)
{   // Some notations in the comments: V1 = vector from indexhat_new-2 control point to the first control point of the arc
	//								   V2 = vector from first to the last control points of the arc.
	float rotation_angle = pi / 2.0;
	float x_direction = *(P + (indexhat_new - 1) * 2 + 0) - *(P + (indexhat_new - 2) * 2 + 0);
	float y_direction = *(P + (indexhat_new - 1) * 2 + 1) - *(P + (indexhat_new - 2) * 2 + 1);
	float theta = atan2(y_direction, x_direction); // This angle indicates which quadrant the direction of V1 is
	float theta2 = atan2(*(P + (indexhat_new)* 2 + 1) - *(P + (indexhat_new - 1) * 2 + 1), *(P + (indexhat_new)* 2 + 0) - *(P + (indexhat_new - 1) * 2 + 0)); // This angle indicates which quadrant the direction V2 is
	int Q = find_quadrant(theta), q = find_quadrant(theta2); // 'Q' is the quadrant of V1. 'q' is the quadrant V2.

	if (fabs(theta) > pi / 2.0) // Modify angle so that it is relative to the horizontal axis
	{
		theta = pi - fabs(theta);
	}

	if (fabs(theta2) > pi / 2.0)
	{
		theta2 = pi - fabs(theta2);
	}

	if (Q == q) // If V1 and V2 are in the same quadrant
	{
		if (Q % 2) // if second or fourth quadrant
		{
			if (fabs(theta) > fabs(theta2)) // If angle of V1 is greater than angle of V2 relative to the horizontal axis, then move the curve -90 degrees towards the path, 
			{
				return -pi / 2.0;
			}
		}
		else// if first or third quadrant
		{
			if (fabs(theta) < fabs(theta2))
			{
				return -pi / 2.0;
			}
		}
	}

	if (abs(Q - q) == 2) // If V1 and V2 are in opposite quadrants, the governing conditions are opposite of the ones for when V1 and V2 are in the same quadrants
	{
		if (Q % 2) // if second or fourth quadrant
		{
			if (fabs(theta) < fabs(theta2))
			{
				return -pi / 2.0;
			}
		}
		else
		{
			if (fabs(theta) > fabs(theta2))
			{
				return -pi / 2.0;
			}
		}
	}

	if (Q == 1 || Q == 2) // Remaining possiblities
	{
		rotation_angle = (float)(Q - q)*rotation_angle;
	}
	else
	{
		if (q < 2)
		{
			return -pi / 2.0;
		}
	}
	return rotation_angle;
}


bool AdjustControlPointForArc(int indexhat, float *P, float Px_mid, float Py_mid, bool arc_segment_found, int *number_of_control_point_mat, int *index_array, int *number_of_failed_u)
{
	// This function has two parts: 1) It works by first adding an intermediate control point for an arc, then it is adjusted such that it is within the segment and would result in the least of of curve points not satisfying the corridor constraint. 
	//							    2) Once the intermediate control point has been appropriately adjusted, two more control points are added, one between the intermediate and the first control point of the arc, another between the intermediate and the last control point of the arc.
	// Px_cur is the current point outside of the segment, Px_mid is the saved coordinates of the new control point
	// For Arc case, look at the tangent direction of the indexhat-1th control point, and move in that direction.
	// index_hat is check_index - 1, or the current index of the control point to be adjusted
	unsigned char controlpixel[4];
	bool cur_point_bounded[2] = { false,false };
	int division = 11, indexhat_new = indexhat;
	float Tx, Ty, dist_x, dist_y;
	static bool prev_point_bounded[2] = { false, false }, first_arc_point = true, first_time = true, finished_adjusting[2] = { false,false }, add_remaining_control_points = false, corridor_checking_initiated = false;
	static int phase_count[2] = { 1, 1 }, start_iteration = 0, iteration = 1, u_compare[2] = { 10000,10000 }, count = 0;
	static float Px_opt[2], Py_opt[2], Pmid[2], Pmid1[2] = { 0.0,0.0 }, Pmid2[2] = { 0.0,0.0 }, rotation_angle = pi / 2.0;

	if (add_remaining_control_points) // If the first newly added control point has been adjusted appropriately, increment the iteration to add two more control points.
	{
		iteration = 2;
		// indexhat is the index of the intermediate control point, so if another control point is to be added between the first and the intermediate control point, this new control point will have the index of indexhat, and the intermediate control point indexhat + 1
		AddControlPoint(indexhat, P, Pmid1, number_of_control_point_mat);
		// After adding a new control point between the first and intermediate control point, the intermediate control point now has index of indexhat+1, so the last control point which is between the intermediate control point and the last control point of the arc will have index of indexhat + 2
		AddControlPoint(indexhat + iteration, P, Pmid2, number_of_control_point_mat);
		add_remaining_control_points = false;
	}

	if (first_time) // Only need to find the direction of rotation angle and update the intermediate control point once because they remain unchanged during the adjusting process
	{
		Pmid[0] = Px_mid;
		Pmid[1] = Py_mid;
		rotation_angle = find_rotation_direction(indexhat_new, P);
		first_time = false;
	}

	for (int i = start_iteration; i < iteration; i++)
	{
		if (!first_arc_point)
		{
			indexhat_new = indexhat + iteration; // This is the second last index of the control point of the arc 
			Pmid[0] = Pmid2[0];
			Pmid[1] = Pmid2[1];
			if (!i)
			{
				Pmid[0] = Pmid1[0];
				Pmid[1] = Pmid1[1];
				indexhat_new = indexhat; // This corresponds to the second index of the control point of the arc
			}
		}

		ReadPathPixel(*(P + (indexhat_new)* 2 + 0), *(P + (indexhat_new)* 2 + 1), controlpixel, 1.0); // Read the pixel of the current control point to see if it is still out of bound
		if (controlpixel[0] == 215 || controlpixel[1] == 215 || controlpixel[2] == 215 || controlpixel[3] == 215)
		{
			cur_point_bounded[i] = false;
		}
		else
		{	// During adjustment of the last remaining control points, when the both of them are within segments, pass their indeces to the check corridor constraint function
			cur_point_bounded[i] = true;
			if (iteration == 2)
			{	// Fine to leave this updating everytime, can implement an if condition of stop updating after the firt time run
				if (cur_point_bounded[0] && cur_point_bounded[1])
				{   // first row corresponds to the second control point of the arc, the second row is the second last control point of the arc
					*index_array = 1;		// the first column of index_array saves the information of whether to start checking corridor constraints, 1 is true, 0 is false, it will always be true for both first time through.
					*(index_array + 1 * 2 + 0) = 1;
					*(index_array + 0 * 2 + 1) = indexhat_new - 2;  // second column contains the indeces of the control points being adjusted
					*(index_array + 1 * 2 + 1) = indexhat_new;
					corridor_checking_initiated = true;
					count++;
				}
			}
		}

		dist_x = (*(P + (indexhat_new + 1) * 2 + 0) - Pmid[0]) * (float)(phase_count[i]) / (float)(division + 10); // This is the distance to move the control point every iteration
		dist_y = (*(P + (indexhat_new + 1) * 2 + 1) - Pmid[1]) * (float)(phase_count[i]) / (float)(division + 10);

		Tx = (cos(rotation_angle) * dist_x - sin(rotation_angle) * dist_y); // This is the displacement to move the control point
		Ty = (sin(rotation_angle) * dist_x + cos(rotation_angle) * dist_y);

		if (cur_point_bounded[i]) // If current control point is bounded
		{
			if (first_arc_point)
			{ // Can't make useful deduction from adjusting the intermediate  control point because parts of the curve are still out of bound
				Px_opt[i] = *(P + (indexhat_new)* 2 + 0);// Save the optimal coordinates for the adjusted control point
				Py_opt[i] = *(P + (indexhat_new)* 2 + 1);
			}
			else
			{ // Only begin saving optimal coordinates when both are within segment for the first time.
				if (corridor_checking_initiated && count > 1)
				{
					if (*(number_of_failed_u + i) < u_compare[i]) // Save the optimal coordinates such that the number of points on the curve not satisfying the corridor constraint is the minumum.
					{
						u_compare[i] = *(number_of_failed_u + i);
						Px_opt[i] = *(P + (indexhat_new)* 2 + 0);// Save the optimal coordinates for the adjusted control point
						Py_opt[i] = *(P + (indexhat_new)* 2 + 1);
					}
				}
			}
		}
		else
		{
			if (prev_point_bounded[i]) // this is for when the adjusted control point within an arc segment becomes unbounded again, so take the previous bounded optimal coordinates.
			{
				// NEED to figure out how to save the optimal position corresponding to the least amount of outbound points + least amount of points not satisfying corridor constraint.
				*(P + (indexhat_new)* 2 + 0) = Px_opt[i];
				*(P + (indexhat_new)* 2 + 1) = Py_opt[i];
				phase_count[i] = 1;
				prev_point_bounded[i] = false;
				finished_adjusting[i] = true;

				if (!i && iteration == 2) // When adjusting for the last remaining two control points for the arc, if the control point closer to the first arc control point is out of segment again, stop adjusting it, move it to last stored optimal coordinates.
				{ // In other words, second last control point of the arc is still adjusting
					start_iteration = 1;
					*(index_array + 0 * 2 + 0) = 0; // turn off corridor constraint checking for the second control point 
				}
				else if (i && iteration == 2) // If the control point closer to the last arc control point is out of segment again, stop adjusting it, move it to last stored optimal coordinates.
				{ // second control point of the arc is still adjusting
					start_iteration = 0;
					iteration = 1;
					*(index_array + 1 * 2 + 0) = 0; // turn off corridor constraint checking for the second last control point
				}

				if (first_arc_point) // If the first intermediate control point is finished adjusted, proceed to adding the last two control points and adjust them.
				{
					finished_adjusting[i] = false;
					first_arc_point = false;
					add_remaining_control_points = true;
					return true; // Return true here meaning control points are still being adjusted
				}

				if (finished_adjusting[0] && finished_adjusting[1])// If all new control points of the arc have been adjusted, return false, reset everything.
				{
					for (int k = 0; k < 2; k++)
					{
						phase_count[k] = 1;
						finished_adjusting[k] = false;
						prev_point_bounded[k] = false;
						u_compare[k] = 10000;
						*(number_of_failed_u + i) = 0;
						for (int j = 0; j < 2; j++)
						{
							*(index_array + k * 2 + j) = 0;
						}
					}
					count = 0;
					corridor_checking_initiated = false;
					rotation_angle = pi / 2.0;
					first_arc_point = true;
					start_iteration = 0;
					iteration = 1;
					first_time = true;
					return false;
				}
				return true;
			}
		}

		*(P + (indexhat_new)* 2 + 0) = Pmid[0] + Tx;
		*(P + (indexhat_new)* 2 + 1) = Pmid[1] + Ty;
		prev_point_bounded[i] = cur_point_bounded[i];
		phase_count[i]++; // This increments the interval to move the point closer to P(index+1)
	}
	return true;
}


void AddControlPoint(int check_index, float *P, float *NewP, int * number_of_control_point_mat)
{
	float Ptemp[100][2];
	// Save the control points that will render the curve within segments
	for (int i = 0; i < check_index; i++)
	{
		Ptemp[i][0] = *(P + i * 2 + 0);
		Ptemp[i][1] = *(P + i * 2 + 1);
	}

	// Calculate mid point 
	*NewP = (*(P + check_index * 2 + 0) + *(P + (check_index - 1) * 2 + 0)) / 2.0;
	*(NewP + 1) = (*(P + check_index * 2 + 1) + *(P + (check_index - 1) * 2 + 1)) / 2.0;

	// Update number of control points
	*(number_of_control_point_mat + 0 * 2 + 0) = *(number_of_control_point_mat + 0 * 2 + 0) + 1;
	for (int i = check_index; i < *(number_of_control_point_mat + 0 * 2 + 0); i++)
	{
		if (i > check_index)
		{
			Ptemp[i][0] = *(P + (i - 1) * 2 + 0);
			Ptemp[i][1] = *(P + (i - 1) * 2 + 1);
		}
		else
		{
			Ptemp[i][0] = *(NewP);
			Ptemp[i][1] = *(NewP + 1);
		}
	}

	for (int i = 0; i < *(number_of_control_point_mat + 0 * 2 + 0); i++)
	{
		*(P + i * 2 + 0) = Ptemp[i][0];
		*(P + i * 2 + 1) = Ptemp[i][1];
	}
}


bool CheckSegmentConstraint(float Cx, float Cy, float *P, int *number_of_control_point_mat, int *index_array, int *number_of_failed_u) // region of each segment is dictated by the control points
{
	// This is like a forward algorithm, need to add a feature to allow backward examination, this is useful for arc.
	// Where this fails: can't drag curve out of segment
	unsigned char pixelpath[4];
	bool index_verified = false;
	static bool arc_segment_found = false, point_is_adjusting = false, arc_point_is_adjusting = false;
	static int check_index, indexhat_new, prev_check_index = 0, index_out[2];
	float Box[4], P_to_P_dist, Center_to_NewP_dist, compare_dist = 1000000.0, segment_center_to_Pout_dist, segment_center_x, segment_center_y, dist1, dist2;
	static float NewP[2];

	if (arc_point_is_adjusting) // This takes priority, because the new control point is outside of the segment or still adjusting to optimal position
	{			// NEED TO FIGURE OUT HOW TO PROPERLY OUTPUT INDECES of the control point when it is inbound again
		arc_point_is_adjusting = AdjustControlPointForArc(check_index - 1, P, NewP[0], NewP[1], arc_segment_found, number_of_control_point_mat, index_array, number_of_failed_u);
		return true;
	}

	if (point_is_adjusting) // This takes priority, because the new control point is outside of the segment or still adjusting to optimal position
	{
		point_is_adjusting = AdjustControlPointForLine(check_index - 1, indexhat_new, P, NewP[0], NewP[1]);
		return true;
	}

	ReadPathPixel(Cx, Cy, pixelpath, 1.0);

	if (pixelpath[0] == 215 || pixelpath[1] == 215 || pixelpath[2] == 215 || pixelpath[3] == 215) // If curve is out of bound of segment
	{

		for (int i = 0; i < *(number_of_control_point_mat + 0 * 2 + 0) - 1; i++) // This for loop finds in which segment the outbound point lies 
		{
			segment_center_x = (*(P + i * 2 + 0) + *(P + (i + 1) * 2 + 0)) / 2.0;
			segment_center_y = (*(P + i * 2 + 1) + *(P + (i + 1) * 2 + 1)) / 2.0;
			segment_center_to_Pout_dist = Distance(segment_center_x - Cx, segment_center_y - Cy);

			if (segment_center_to_Pout_dist < compare_dist)
			{
				compare_dist = segment_center_to_Pout_dist;
				check_index = i + 1;
			}
		}

		Center_to_NewP_dist = Distance((*(P + check_index * 2 + 0) + *(P + (check_index - 1) * 2 + 0)) / 2.0 - Cx, (*(P + check_index * 2 + 1) + *(P + (check_index - 1) * 2 + 1)) / 2.0 - Cy);
		P_to_P_dist = Distance(*(P + check_index * 2 + 0) - *(P + (check_index - 1) * 2 + 0), *(P + check_index * 2 + 1) - *(P + (check_index - 1) * 2 + 1));// Maybe compare distance of center?
		if (P_to_P_dist < Center_to_NewP_dist)
		{
			check_index++;
		}

		AddControlPoint(check_index, P, NewP, number_of_control_point_mat);

		// Note check_index at this line is now the index of the new control point
		ReadPathPixel(*(P + check_index * 2 + 0), *(P + check_index * 2 + 1), pixelpath, 1.0); // check if new control point is outside of the segment or not
		arc_point_is_adjusting = false;

		if (pixelpath[0] == 215 || pixelpath[1] == 215 || pixelpath[2] == 215 || pixelpath[3] == 215)
		{
			arc_point_is_adjusting = true;
		}
		else
		{
			point_is_adjusting = true;
			// If the new control point is within a straight line segment, find the direction to move the new control point
			dist1 = Distance(*(P + (check_index + 1) * 2 + 0) - Cx, *(P + (check_index + 1) * 2 + 1) - Cy);
			dist2 = Distance(*(P + (check_index - 1) * 2 + 0) - Cx, *(P + (check_index - 1) * 2 + 1) - Cy);

			if (dist1 > dist2) // if previous control point is closer to the point of curve outside of segment move in towards the previous control point
			{
				indexhat_new = check_index - 1;
			}
			else
			{
				indexhat_new = check_index + 1;
			}
		}
		// Note check_index at this line is the index of the control point after the new control point
		check_index++;
		prev_check_index = check_index;

		return true;
		//DrawOutOfMapPoints(Cx, Cy);
	}
	return false;
}


int FindAverageFailedKnots(float *u_fail, float *u_final, int u_fail_count)
{
	// Find the average u at every clutter
	float u_temp = *(u_fail + 0*2 + 0), u_temp_index = *(u_fail + 0 * 2 + 1);
	int p = 0, count = 1 , count_temp = 1, index_average;

	for (int i = 1;i < u_fail_count; i++)
	{
		float diff = *(u_fail + i * 2 + 0) - *(u_fail + (i-1) * 2 + 0);

		if (diff >= 0.01)
		{
			index_average = (int)(((float)count + (float)count_temp) / 2.0);
			*(u_final + p * 2 + 0) = *(u_fail + index_average * 2 + 0);// u_temp / (float)count;
			*(u_final + p * 2 + 1) = *(u_fail + index_average * 2 + 1);// floor(u_temp_index / (float)count);
			count_temp = count;
			p++;
		}
		else
		{
			count++;
			if (i == u_fail_count - 1)
			{
				index_average = (int)(((float)count + (float)count_temp) / 2.0);
				*(u_final + p * 2 + 0) = *(u_fail + index_average * 2 + 0); u_temp / (float)count;
				*(u_final + p * 2 + 1) = *(u_fail + index_average * 2 + 1); floor(u_temp_index / (float)count);
				p++;
			}
		}
	}

	return p;
}


void ReadjustControlPoint(float *P, float *P_fail, float Cx, float Cy, float tolerance, float d_constraint, float u_fail, float *knot_vector, int degree, int number_of_control_points)
{
	unsigned char pixelpath[4];
	int span, adjust_index, adjust_index_new;
	float d_fail = Distance(Cx - *(P_fail), Cy - *(P_fail + 1));
	float d_travel = d_constraint - d_fail + tolerance;
	float theta = atan2((*(P_fail + 1) - Cy), (*(P_fail)-Cx));
	float Tx = d_travel*cos(theta), Ty = d_travel*sin(theta);
	float V[2], N[4], t[100], comp = 10000.0, alpha, Ptemp_x, Ptemp_y;
	clear_mat(100, t);

	V[0] = -1.0*Tx;
	V[1] = -1.0*Ty;

	span = findSpan(number_of_control_points-1, degree,u_fail, knot_vector);
	BasisFunctions(span, u_fail, degree, knot_vector,N);
	// Generate nodes
	for (int i = 0; i < number_of_control_points; i++)
	{
		for (int j = 1; j <= degree;j++)
		{
			t[i] += *(knot_vector + i + j); // eq11.4
		}
		t[i] *= 1.0 / (float)degree;
	}
	// find the index to adjust 
	for (int i = 0; i < (number_of_control_points-1) + degree + 2; i++)
	{
		float d = fabs(u_fail - t[i]); // eq11.5
		if (d < comp)
		{
			comp = d;
			adjust_index = i;
		}
	}
	// manipulate the index so it matches with the index returned by basis function 
	adjust_index_new = adjust_index - (span - degree); 
	alpha = d_travel / (magnitude(V, 2) * N[adjust_index_new]); // eq11.3

	Ptemp_x = *(P + adjust_index * 2 + 0) + alpha * V[0];  // eq11.2
	Ptemp_y = *(P + adjust_index * 2 + 1) + alpha * V[1];

	ReadPathPixel(Ptemp_x, Ptemp_y, pixelpath, 1);
	if (pixelpath[0] == 215 || pixelpath[1] == 215 || pixelpath[2] == 215 || pixelpath[3] == 215)
	{
		return;
	}
	else 
	{
		*(P + adjust_index * 2 + 0) = Ptemp_x;
		*(P + adjust_index * 2 + 1) = Ptemp_y;
	}
	
}

float magnitude(float *P, int dimension)
{
	if (dimension == 2)
	{
		return sqrt(pow(*(P), 2.0) + pow(*(P + 1), 2.0));
	}
}