void FindNormalAndTangent(float Cx, float Cy, float dCx, float dCy, float *Tangent, float *Normal, float scale);

void CheckCorridorConstraint(float *Normal, float Cx, float Cy, float corridor_constraint, int *constraint_info, float *P_fail);

bool CheckSegmentConstraint(float Cx, float Cy, float *P, int *number_of_control_point_mat, int *index_array, int *number_of_failed_u);

bool AdjustControlPointForArc(int indexhat, float *P, float Px_mid, float Py_mid, bool arc_segment_found, int *number_of_control_point_mat, int *index_array, int *number_of_failed_u);

bool AdjustControlPointForLine(int indexhat, int indexhat_new, float *P, float Px_mid, float Py_mid);

void AddControlPoint(int check_index, float *P, float *NewP, int * number_of_control_point_mat);

void ReadPathPixel(float Cx, float Cy, unsigned char *pixelpath, float offset);

int find_quadrant(float theta);

float find_rotation_direction(int indexhat_new, float *P);

float Distance(float dx, float dy);

int FindAverageFailedKnots(float *u_fail, float *u_final, int u_fail_count);

float magnitude(float *P, int dimension);

void ReadjustControlPoint(float *P, float *P_fail, float Cx, float Cy, float tolerance, float d_constraint, float u_fail, float *knot_vector, int degree, int number_of_control_points);

