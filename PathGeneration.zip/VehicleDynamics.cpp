#include <gl/glew.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include <gl/freeglut.h>
#include <math.h>
#include "VehicleDynamics.h"
#include "matrixOperation.h"
#include <stdio.h>
#include <stdlib.h>

const long double pi = 3.141592653589793238L;

float pid_controller(float Kp, float Ki, float Kd, float error, float delta_T)
{
	float up = Kp*error;
	static float xd = 0.0, xi = 0.0;
	float ud = Kd*(error / delta_T - xd);
	float ui = Ki*delta_T*(error + xi);

	xd = error / delta_T;
	xi += error;
	printf("%3.2f %3.2f %3.2f\r\n", up, ud, ui);
	return up + ud + ui;
}

void vehicle_trajectory(float *initial_conditions,float longitudinal_velocity, float *output_states, float yaw_rate_input, float delta_T)
{
	float u[2] = { longitudinal_velocity,yaw_rate_input };
	static float q[3] = {*initial_conditions, *(initial_conditions + 1), *(initial_conditions + 2)};
	float qdot[3] = { 0.0,0.0,0.0};
	float qnext[3];

	qdot[0] = cos(q[2])*u[0];
	qdot[1] = sin(q[2])*u[0];
	qdot[2] = u[1];

	MatrixScalarMultiply(qdot, 3, 1, delta_T);
	MatrixAdd(q, qdot, 3, 1, qnext);

	for (int i = 0; i < 3; i++)
	{
		*(output_states + i) = qnext[i];
		q[i] = qnext[i];
	}
}

float heading_to_curve_distance(float center_x, float center_y, float yaw_angle, float longitudinal_velocity, float *V_out, bool *zero_error)
{
	float x_comp = longitudinal_velocity*cos(yaw_angle), y_comp = longitudinal_velocity*sin(yaw_angle);
	float V_head_x = center_x + x_comp, V_head_y = center_y + y_comp, initial_dist = 0.0, Normal_Left_x, Normal_Left_y, Normal_Right_x, Normal_Right_y;
	bool curve_intersect_found = false;
	unsigned char pixel_left, pixel_right;
	float compensate_sign = 1.0;

	while (!curve_intersect_found)
	{
		Normal_Left_x = (-1.0*initial_dist*sin(yaw_angle) + V_head_x);
		Normal_Left_y = (initial_dist*cos(yaw_angle) + V_head_y);
		Normal_Right_x = (initial_dist*sin(yaw_angle) + V_head_x);
		Normal_Right_y = (-1.0*initial_dist*cos(yaw_angle) + V_head_y);
		glReadPixels((GLint)Normal_Left_x, (GLint)Normal_Left_y, 1, 1, GL_GREEN, GL_UNSIGNED_BYTE, &pixel_left);
		glReadPixels((GLint)Normal_Right_x, (GLint)Normal_Right_y, 1, 1, GL_GREEN, GL_UNSIGNED_BYTE, &pixel_right);
		printf("%d %d\r\n",pixel_left, pixel_right);
		if (pixel_left == 255 && pixel_right == 255) // zero error case
		{
			*(V_out) = V_head_x;
			*(V_out + 1) = V_head_y;
			*zero_error = true;
			break;
		}
		if (pixel_left == 255)
		{
			*(V_out) = Normal_Left_x;
			*(V_out + 1) = Normal_Left_y;
			break;
		}
		if (pixel_right == 255)
		{
			*(V_out) = Normal_Right_x;
			*(V_out + 1) = Normal_Right_y;
			compensate_sign = -1.0;
			break;
		}
		initial_dist += 1.0;
	}
	return compensate_sign;
}
