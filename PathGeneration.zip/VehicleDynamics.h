

float pid_controller(float Kp, float Ki, float Kd, float error, float delta_T);

void vehicle_trajectory(float *initial_conditions, float longitudinal_velocity, float *output_states, float yaw_rate_input, float delta_T);

float heading_to_curve_distance(float center_x, float center_y, float yaw_angle, float longitudinal_velocity, float *V_out, bool *zero_error);
