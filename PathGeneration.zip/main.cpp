#include <windows.h>
#include <gl/glew.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>
#include <gl/freeglut.h>
#include <stddef.h>
#include <string.h>
#include <iomanip>
#include "math.h"
#include "BSplineFunctions.h"
#include "PathGeneration.h"
#include "DrawCurves.h"
#include "VehicleDynamics.h"
#include <stdio.h>
#include <stdlib.h>

const long double pi = 3.141592653589793238L;

// Screen resolutions and windows origin
const int screenWidth = 1000, screenHeight = 700, WindowPosX = 0, WindowPosY = 0;
GLfloat LineWidth = 2.0;

// Curve parameters
static int number_of_control_points = 0;
static int number_of_curves = 0;
static int number_of_points = 0;
int number_of_control_points_mat[100][2];
float P[100][2];
float Q[100][2];
int degree = 3;

// Knot Vector Parameter Declaration
float knot_vector[40];
float knot_vector_new[40];
bool knot_inserted = false;
float u_fail[1000][2];
float u_final[1000][2];
int u_fail_count = 0;

// keyboard key declarations
static unsigned char a_key = 0x00, s_key = 0x00, esc_key = 0x00, e_key = 0x00, u_key = 0x00, t_key = 0x00, plus_key = 0x00, minus_key = 0x00, p_key = 0x00;
unsigned char mask = 0xff;

// Derivatives, normal, and tangent declarations
float Params[3][2];
float CK[3][2];
float Tangent[2], Normal[2][2];
bool draw_derivs = false;
extern output output_struct[3][1000];


// Map Declarations
float path_width = 40.0; // 40 pixel wide
float constraint_width = 15;// the normal distant from current point on the curve to one side of the maximum allowable distance.
float map[40][10], map_hat[40][10];
int EasyMapPoints = 6;
int MediumMapPoints = 15;
int InsaneMapPoints = 25;
int NumberOfMapPoints = InsaneMapPoints;
FILE *fp;

// Control Point Editing Declarations
int cp_index_to_edit = 0;

// Segment checking parameters
bool segment_check_complete = false;
int iteration, span[2], start_iteration[2], end_iteration[2];
float u_new[2];
static int index_array[2][2] = { {0,0},{0,0} }, start_search = 0, end_search = 1000;
static bool checking_corridor_constraint = false;

// Corridor constraint checking parameters
float P_fail[2];

// Animation
const int LOOP_INTERVAL_MSEC = 50;
float TIME = 0.0;

// Vehicle Simulation
float Kp = 2.0, Kd = 0.0, Ki = 0.0, omega, longitudinal_velocity = 20.0, output_states[3], error, vehicle_width = 12.0, vehicle_length = 20.0;
float dist_curve_to_vehicle_center = 0.0, compensate_sign, V_out[2];
int initial_count = 1, backward_start_iteration;
static bool first_time = true;
static float states[3];

void Animation(int value)
{
	if (a_key)
	{
		bool zero_error = false;
		printf("HERE ANIME\r\n");
		if (first_time) // calculate initial conditions
		{
			states[0] = output_struct[0][0].PK[0]; // xc
			states[1] = output_struct[0][0].PK[1]; // yc
			// Find the initial orientation based on the initial vehicle center and where the projected vehicle heading point intersects the curve, in other words, when the distance between the vehicle center to a point on the curve is equal to the length of projected vehicle heading.
			while (dist_curve_to_vehicle_center <= longitudinal_velocity)
			{
				dist_curve_to_vehicle_center = Distance(output_struct[0][initial_count].PK[0] - states[0], output_struct[0][initial_count].PK[1] - states[1]);
				initial_count++;
				printf("%3.2f\r\n", dist_curve_to_vehicle_center);
			}
			// yaw angle
			states[2] = atan2(output_struct[0][initial_count - 1].PK[1] - states[1], output_struct[0][initial_count - 1].PK[0] - states[0]);
			first_time = false;
		}
		// this sign dictates the sign of error, which in turn decides the direction of compensated yaw rotation
		compensate_sign = heading_to_curve_distance(states[0], states[1], states[2], longitudinal_velocity, V_out,&zero_error);
		if (!zero_error)
		{
			// find the iteration for backwards search of the perpendicular distance from the curve to the projected point of the vehicle heading
			for (int i = start_search; i < end_search; i++)
			{
				if ((output_struct[0][i].PK[1] < V_out[1] + 2.0) && (output_struct[0][i].PK[1] > V_out[1] - 2.0) && (output_struct[0][i].PK[0] < V_out[0] + 2.0) && (output_struct[0][i].PK[0] > V_out[0] - 2.0))
				{
					backward_start_iteration = i;
					if (i > 50)
					{
						start_search = i - 50;
					}
					break;
				}
			}

			// Compute the distance between the point on the curve to the vehicle heading, this distance is perpendicular from the vehicle heading
			float Lp = Distance(V_out[0] - output_struct[0][backward_start_iteration].PK[0], V_out[1] - output_struct[0][backward_start_iteration].PK[1]);
			error = 1.0*compensate_sign*Lp;
			// Find the point that results in perpendicular distance to the vehicle heading from the curve using Law of Cosine
			//for (int j = backward_start_iteration - 1; j > 0; j--)
			//{
			//	// distance between the point on the curve at index = backward start iteration to where the point it is currently searching.
			//	float Lc = Distance(output_struct[0][backward_start_iteration].PK[0] - output_struct[0][j].PK[0], output_struct[0][backward_start_iteration].PK[1] - output_struct[0][j].PK[1]);
			//	// This should be the perpendicular distance or feedback error to the controller when it is determined
			//	float Lerror = Distance(output_struct[0][j].PK[0] - V_out[0], output_struct[0][j].PK[1] - V_out[1]);
			//	float theta = acos((Lc*Lc + Lerror*Lerror - Lp*Lp) / (2.0*Lc*Lerror));

			//	if ((theta > (pi / 2.0 - 2.0*pi / 180.0)) && (theta < (pi / 2.0 + 2.0*pi / 180.0))) // if it is close to right angle
			//	{
			//		error = compensate_sign*Lerror;
			//		break;
			//	}
			//}
		}
		else
		{
			error = 0.0;
		}
		omega = pid_controller(Kp, Ki, Kd, error, (float)LOOP_INTERVAL_MSEC/1000.0);

		vehicle_trajectory(states, longitudinal_velocity, output_states, omega, (float)LOOP_INTERVAL_MSEC/1000.0);
		for (int i = 0; i < 3; i++)
		{
			states[i] = output_states[i];
		}
		
	}
	
	glutPostRedisplay();
	glutTimerFunc(LOOP_INTERVAL_MSEC, Animation, 0);

}

void displayText(char *string, float x, float y, float z)
{
	char *c;
	glRasterPos3f(x, y, z);

	for (c = string; *c != '\0'; c++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *c);
	}
}

void passive_motion(int mouse_pos_x, int mouse_pos_y) // Previews the curve before selecting the next control point
{
	int Passive_x = mouse_pos_x, Passive_y = screenHeight- mouse_pos_y;

		//printf("%d %d\r\n", Passive_x, Passive_y);
	
	/*unsigned char pixel[3];
	glReadPixels((GLint)mouse_pos_x, (GLint)Passive_y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
	printf("r: %d, g: %d, b: %d\r\n", pixel[0], pixel[1], pixel[2]);*/

	if (!draw_derivs)
	{
		if (number_of_control_points > 1)
		{
			P[number_of_points][0] = (float)Passive_x;
			P[number_of_points][1] = (float)Passive_y;

			number_of_control_points_mat[number_of_curves][0] = number_of_control_points + 1;
		}
	}
	glutPostRedisplay();

}

void mouse_button(int button, int state, int mouse_pos_x, int mouse_pos_y)
{
	int Px, Py;
	Px = mouse_pos_x;
	Py = screenHeight - mouse_pos_y;

	if (!p_key)
	{
		if (button == GLUT_LEFT_BUTTON) // Saves the control point
		{
			switch (state)
			{
			case GLUT_DOWN:
				if (!draw_derivs) // If draw_derivs is true, done drawing, only editing mode is allowed
				{
					P[number_of_points][0] = (float)Px;
					P[number_of_points][1] = (float)Py;
					number_of_control_points++;
					number_of_points++;
					number_of_control_points_mat[number_of_curves][0] = number_of_control_points;
				}
				break;
			}
		}
		else if (button == GLUT_RIGHT_BUTTON) // Creates a new curve
		{
			switch (state)
			{
			case GLUT_DOWN:
				draw_derivs = true;
				number_of_control_points_mat[number_of_curves][0] = number_of_control_points;
				//number_of_curves++;
				//number_of_control_points_mat[number_of_curves][1] = number_of_points;
				//number_of_control_points = 0;


				break;
			}
		}
	}
	glutPostRedisplay();
}

void mouse_button_motion(int mouse_x, int mouse_y)
{
	int Px = mouse_x, Py = screenHeight - mouse_y;

	if (p_key)
	{
		float dist = sqrt(pow((float)Px - P[cp_index_to_edit][0], 2.0) + pow((float)Py - P[cp_index_to_edit][1], 2.0));

		if (dist < 10)
		{
			P[cp_index_to_edit][0] = (float)Px;
			P[cp_index_to_edit][1] = (float)Py;
		}
	}

	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) // Turns on and off the points and polygons
	{

	case 0x61: // a key
		a_key ^= mask;
		break;

	case 0x1B: // escape key
		esc_key ^= mask;
		break;

	case 0x65: // edit key
		e_key ^= mask;
		if (e_key)
		{			
			printf("Current knot vector U:\r\n");
			printf("[");
			for (int i = 0; i < GetNumberOfKnots()+1; i++) // Print out current knot vector
			{
				printf("%1.4f ",*(GetKnotVector()+i));
			}
			printf("]\r\n");

			printf("\r\n");

			printf("Enter a new knot 'uhat' between 0 and 1:\r\n");
			char val[100];
			float uhat;
			fgets(val, 100, stdin);
			sscanf_s(val, "%f", &uhat);
			printf("uhat: %1.4f\r\n", uhat);

			printf("\r\n");

			printf("Enter the number of times 'r' to insert 'uhat' :\r\n");
			char rval[100];
			int r;
			fgets(rval, 100, stdin);
			sscanf_s(rval, "%d", &r);

			int KnotParameters[3] = { 0,0,0 };
			FindKnotParameters(GetKnotVector(), degree, number_of_control_points_mat[0][0], uhat, r, KnotParameters);

			if (KnotParameters[2]) // If the number of times 'r' to insert the knot is non-zero
			{
				printf("\r\n");

				int number_of_new_control_points = CurveKnotIns(number_of_control_points_mat[0][0], degree, GetKnotVector(),
					P[0], uhat, KnotParameters[0], KnotParameters[1], KnotParameters[2], knot_vector_new, Q[0]);
				printf("New knot vector:\r\n");
				printf("[");
				for (int i = 0; i < GetNumberOfKnots() + KnotParameters[2] + 1; i++)
				{
					printf("%1.3f ", knot_vector_new[i]);
					knot_vector[i] = knot_vector_new[i]; // Update knot vector when the new inserted knot
				}
				printf("]\r\n");

				number_of_control_points_mat[0][0] = number_of_new_control_points; // Update the number of control points

				for (int i = 0; i < number_of_new_control_points; i++)
				{
					for (int j = 0; j < 2; j++)
					{
						P[i][j] = Q[i][j]; // Update control points
					}
				}

				knot_inserted = true;
				e_key ^= mask; // reset e_key, so user has to press e_key again to insert another knot
			}
			else
			{
				e_key ^= mask; // reset e_key, so user has to press e_key again to insert another knot
				printf("At uhat = %1.3f, knot multiplicity s = %d, is bigger than degree p = %d, so it can't be inserted.\r\n", uhat, KnotParameters[1], degree);
			}
		}
		break;

	case 0x74: // t - draw failed u knot points on the curve
		t_key ^= mask;
		break;

	case 0x75: // u - display u know values
		u_key ^= mask;
		break;

	case 0x7A: // z - increase curve degree
		degree++;
		break;

	case 0x78: // x - decrease curve degree
		degree--;
		break;

	case 0x2B: // + - move to next control point in control point editing mode
		if (cp_index_to_edit < number_of_control_points_mat[0][0]-1)
		{
			cp_index_to_edit++;
		}
		break;

	case 0x2D: // - move to previous control point in control point editing mode
		if (cp_index_to_edit)
		{
			cp_index_to_edit--;
		}
		break;

	case 0x70: // p - enable control point editing mode
		p_key ^= mask;
		break;

	case 0x73: // p - enable control point editing mode
		s_key ^= mask;
		break;

	}
	glutPostRedisplay();
}

void Init(void)
{
	glClearColor(1.0, 215.0/255.0,0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)screenWidth, 0.0, (GLdouble)screenHeight);
}

void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, w, 0, h);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void Display(void)
{
	static bool check_constraints = false, adjust_phase_two = false, corridor_constraint_checked = false, mission_accomplished = false, reduce_u_fail_array = false;
	static int phase_two_iteration = 1, adjust_index = 0, number_of_failed_average_knots = 0, loop_count = 1;
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glColor3f(0.0f, 1.0f, 0.0f);

	// Draw Map
	DrawMapContour(NumberOfMapPoints, map[0]); // Draw top half of map contour
	DrawMapContour(NumberOfMapPoints, map_hat[0]); // Draw bottom half of map contour
	DrawPath(NumberOfMapPoints, map[0], map_hat[0]); // Draw map path, useful for checking if line is within segments of map

	// Check if the curve is within segment
	if (s_key)
	{

		for (int i = 0; i < 1000; i++)
		{
			if (i == 999)
			{
				segment_check_complete = true;
			}
			if (!segment_check_complete)
			{
				int number_of_failed_u[2] = { 0,0 }, start = 0;

				if (checking_corridor_constraint) // this checks the number of points on the curve that do not satisfy the corridor constraint, it starts by identifying the 'u' span that corresponds to the current adjusting control point
				{
					if (index_array[0][0] && index_array[1][0]) // if both true
					{
						iteration = 2;
					}
					else if (index_array[0][0]) // first one is still within bound and hasn't stop adjusting yet
					{
						iteration = 1;
					}
					else if (index_array[1][0]) // second one is still within bound and hasn't stop adjusting yet
					{
						iteration = 2;
						start = 1;
					}
					else if (!index_array[0][0] && !index_array[1][0]) // done adjusting and checking constraint, reset parameters and skip the for-loop
					{
						start = 0;
						iteration = 2;
						checking_corridor_constraint = false;
						continue; // go back to the beginning of the for-loop, will skip one iteration, but that shouldn't matter because it's the first one anyway.
					}
					// this for loop performs corridor constraint on the span that is only influenced by the current control point and the three adjacent control points
					for (int j = start; j < iteration; j++)
					{

						span[j] = index_array[j][1] + 1;
						start_iteration[j] = (int)(*(GetKnotVector() + span[j]) * 1000.0);
						end_iteration[j] = (int)(*(GetKnotVector() + span[j] + 1) * 1000.0);
						for (int k = start_iteration[j]; k < end_iteration[j]; k++)
						{
							int constraint_info[2] = { 1,1 }; // first element = 1 meaning constraint up is met.

							FindNormalAndTangent(output_struct[0][k].PK[0], output_struct[0][k].PK[1], output_struct[1][k].PK[0], output_struct[1][k].PK[1], Tangent, Normal[0], constraint_width); // find normal and tangent vectors
							CheckCorridorConstraint(Normal[0], output_struct[0][k].PK[0], output_struct[0][k].PK[1], constraint_width, constraint_info,P_fail); // check constraint along normal vector

							if (!constraint_info[0] || !constraint_info[1])
							{
								number_of_failed_u[j]++;
							}
						}
					}
				}

				bool update_curve;

				update_curve = CheckSegmentConstraint(output_struct[0][i].PK[0], output_struct[0][i].PK[1], P[0], number_of_control_points_mat[0], index_array[0], number_of_failed_u);

				if (index_array[0][0] && index_array[1][0]) // both remaining points being adjusted are finally within segment, initiate corridor checking
				{
					checking_corridor_constraint = true;
				}

				// Need to figure out how to start evaluating 'u' in certatin span and pass that into checksegmentconstraint.
				if (update_curve) // If curve needs to be updated after segment check, then break out of this loop and draw the new curve
				{
					break;
				}
			}
		}
	}

	// Check corridor constraint and obtain an array of knots that do not satisfy the corridor constraint
	if (!mission_accomplished && segment_check_complete && !corridor_constraint_checked )//(t_key)
	{
		u_fail_count = 0;
		for (int i = 0; i < 1000; i++)
		{
			int constraint_info[2] = { 1,1 }; // first element = 1 meaning constraint up is met.
			float u = (float)i / (float)(1000 - 1);
			FindNormalAndTangent(output_struct[0][i].PK[0], output_struct[0][i].PK[1], output_struct[1][i].PK[0], output_struct[1][i].PK[1], Tangent, Normal[0], constraint_width); // find normal and tangent vectors
			CheckCorridorConstraint(Normal[0], output_struct[0][i].PK[0], output_struct[0][i].PK[1], constraint_width, constraint_info,P_fail); // check constraint along normal vector

			if (!constraint_info[0] || !constraint_info[1])
			{
				u_fail[u_fail_count][0] = u;
				u_fail[u_fail_count][1] = i;

				u_fail_count++;
			}
		}
		printf("There are %d failed knots.\r\n",u_fail_count);
		if (!u_fail_count)
		{
			mission_accomplished = true;
		}
		else
		{
			corridor_constraint_checked = true;
			reduce_u_fail_array = true;
		}
	}

	if (adjust_phase_two)
	{
		int constraint_info[2] = { 1,1 };
		FindNormalAndTangent(output_struct[0][(int)u_final[adjust_index][1]].PK[0], output_struct[0][(int)u_final[adjust_index][1]].PK[1], output_struct[1][(int)u_final[adjust_index][1]].PK[0], output_struct[1][(int)u_final[adjust_index][1]].PK[1], Tangent, Normal[0], constraint_width); // find normal and tangent vectors
		CheckCorridorConstraint(Normal[0], output_struct[0][(int)u_final[adjust_index][1]].PK[0], output_struct[0][(int)u_final[adjust_index][1]].PK[1], constraint_width, constraint_info, P_fail); // check constraint along normal vector

		if (constraint_info[0] && constraint_info[1]) // Constraint is met
		{
			if (adjust_index == number_of_failed_average_knots)
			{
				corridor_constraint_checked = false;
				reduce_u_fail_array = false;
				adjust_phase_two = false;
				phase_two_iteration = 1;
				adjust_index = 0;
			}
			else
			{
				adjust_index++;
				phase_two_iteration = 1;
			}
		}
	}

	if (reduce_u_fail_array) 
	{
		reduce_u_fail_array = false;
		// Find the average u at every clutter, return the number of failed knots
		if (u_fail_count == 1)
		{
			number_of_failed_average_knots = 1;
			u_final[0][0] = u_fail[0][0];
			u_final[0][1] = u_fail[0][1];
			printf("Number of failed knots are reduced to %d after averaging the clutters.\r\n", number_of_failed_average_knots);
			adjust_phase_two = true;
		}
		else if (u_fail_count == 0)
		{
			adjust_phase_two = false;
		}
		else
		{
			number_of_failed_average_knots = FindAverageFailedKnots(u_fail[0], u_final[0], u_fail_count);
			printf("Number of failed knots are reduced to %d after averaging the clutters.\r\n", number_of_failed_average_knots);
			adjust_phase_two = true;
		}
	}
	
	if (phase_two_iteration > 3) // insert new knots
	{
		phase_two_iteration = 0;
		adjust_phase_two = false;

		float uhat = u_final[adjust_index][0];
		for (int j = 0; j < number_of_control_points_mat[0][0] + degree + 1; j++)
		{
			if (uhat == knot_vector[j])
			{
				uhat = uhat - 0.001; // avoid inserting the same knot
				break;
			}
		}
		number_of_control_points_mat[0][0] = InsertNewKnot(degree, number_of_control_points_mat[0][0], uhat, 1, knot_vector, knot_vector_new, P[0], Q[0]);
		corridor_constraint_checked = false;
	}

	if (adjust_phase_two) // start readjusting the control points based on location of failed knots and find the corresponding nodes.
	{
		printf("Iteration: %d, Control Points: %d\r\n", loop_count, number_of_control_points_mat[0][0]);
		loop_count++;
		int constraint_info[2] = { 1,1 };
		// reevaluate at the indeces where the knots fail to meet the corridor constraint to obtain the failed distance 
		FindNormalAndTangent(output_struct[0][(int)u_final[adjust_index][1]].PK[0], output_struct[0][(int)u_final[adjust_index][1]].PK[1], output_struct[1][(int)u_final[adjust_index][1]].PK[0], output_struct[1][(int)u_final[adjust_index][1]].PK[1], Tangent, Normal[0], constraint_width); // find normal and tangent vectors
		CheckCorridorConstraint(Normal[0], output_struct[0][(int)u_final[adjust_index][1]].PK[0], output_struct[0][(int)u_final[adjust_index][1]].PK[1], constraint_width, constraint_info,P_fail); // check constraint along normal vector
	
		if (!constraint_info[0] || !constraint_info[1]) // Only re-adjust if valid
		{
			ReadjustControlPoint(P[0], P_fail, output_struct[0][(int)u_final[adjust_index][1]].PK[0], output_struct[0][(int)u_final[adjust_index][1]].PK[1], 2.0,constraint_width, u_final[adjust_index][0], knot_vector,degree, number_of_control_points_mat[0][0]);
		}
		phase_two_iteration++;
	}
	

	if (p_key)
	{
		DrawEditControlPointCircle(P[cp_index_to_edit][0], P[cp_index_to_edit][1]);
	}

	// This for-loop plots all curve(s)
	for (int i = 0; i < number_of_curves + 1; i++) 
	{
		if (number_of_control_points_mat[i][0] > 0)
		{
			if (!esc_key)
			{
				DrawControlPoints(number_of_control_points_mat[i][0], number_of_control_points_mat[i][1], (float)screenWidth, (float)screenHeight, P[0]);
			}
		}
		if (number_of_control_points_mat[i][0] > 1)
		{
			if (!esc_key)
			{
				DrawPolygon(number_of_control_points_mat[i][0], number_of_control_points_mat[i][1], (float)screenWidth, (float)screenHeight, P[0]);
			}

			if (number_of_control_points_mat[i][0] - 1 >= degree)
			{
				DrawBSplineCurve(number_of_control_points_mat[i][0], number_of_control_points_mat[i][1], degree, (float)screenWidth, (float)screenHeight, P[0],knot_vector,knot_inserted);
				
			}
		}
		
	}

	if (a_key)
	{
		printf("%3.2f %3.2f %3.2f\r\n", states[0], states[1], states[2] * 180.0 / pi);
		DrawVehicle(states[0], states[1], states[2], vehicle_width, vehicle_length);
	}

	glutSwapBuffers();
}

void main(int argc, char** argv)
{
	fopen_s(&fp, "InsaneMap.txt", "r"); // read map

	for (int i = 0; i < NumberOfMapPoints*2; i++)
	{
		if (i < NumberOfMapPoints)
		{
			for (int j = 0; j < 10; j++)
			{
				fscanf_s(fp, "%f", &map[i][j]);
			}
		}
		else
		{
			for (int j = 0; j < 10; j++)
			{
				fscanf_s(fp, "%f", &map_hat[i-NumberOfMapPoints][j]);
			}
		}
	}
	fclose(fp);

	glutInit(&argc, argv);
	number_of_control_points_mat[0][0] = 0;
	number_of_control_points_mat[0][1] = 0;
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(screenWidth, screenHeight);
	glutInitWindowPosition(WindowPosX, WindowPosY);
	glutCreateWindow("Final Project");
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse_button);
	glutMotionFunc(mouse_button_motion);
	glutPassiveMotionFunc(passive_motion);
	glutDisplayFunc(Display);
	glutIdleFunc(Display);
	glutReshapeFunc(reshape);
	glutTimerFunc(LOOP_INTERVAL_MSEC, Animation, 0);
	Init();
	glutMainLoop();
	
}
