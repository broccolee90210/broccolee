#ifndef _matrixOperation_h
#define _matrixOperation

void MatrixScalarMultiply(float *mat_ptr, int row, int col, float scalar_value);

void MatrixAdd(float *mat_ptr1, float *mat_ptr2, int row, int col, float *mat_result);

void MatrixSubtract(float *mat_ptr1, float *mat_ptr2, int row, int col, float *mat_result);

void MatrixMultiply(float *mat_ptr1, int row1, int col1, float *mat_ptr2, int row2, int col2, float *mat_result);

static void determinant(float *mat, int size, float *det_result);

void transpose(float *mat, int rol, int col, float *mat_result);

static void adjoint(float *mat, int size, float *mat_result);

void inverse(float *mat, int size, float *mat_result);

void identityMat(int size, float *mat_result, float constant);

void clearMatrix(float *mat, int row, int col);

float dot(float *vec_ptr1, float *vec_ptr2, int vector_length);

void vector_cross(float *v1, float *v2, float *v_result);

float vector_norm(float *vin, int power);

void quat_vector(float *q, float *result);

void append_quat(float *real, float *vector, float *result);

void QuaternionMultiplication(float *p, float *q, float *result);

void QuaternionOperator(float *q, float *v, float *result);

#endif
