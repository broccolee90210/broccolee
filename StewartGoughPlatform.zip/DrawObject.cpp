#include "DrawObject.h"
#include "Transformation.h"
#include<math.h>
#include<stdlib.h>
#include<vector>
const long double pi = 3.141592653589793238L;
using namespace std;


float length_upper_new = 50.0+2;
float d1new = sqrt(length_upper_new*length_upper_new - length_upper_new*length_upper_new/4.0)/2.0 ;
float width                  = 2.0;
float theta				     = atan(2.0*d1new/(length_upper_new/2.0));
float a						 = width / tan(  theta / 2.0  );
float b					     = 2.0*d1new - ( ( (length_upper_new/2.0) - a )*tan(theta) + width );
float thickness              = -2.0;
float actuator_chassis = 30.0;

GLfloat rosy_brown[] = {1.0,193.0/255.0,193.0/255.0,1.0};
GLfloat azure[] = {244.0/255.0,1.0,1.0,1.0};
GLfloat black[] = {0.0,0.0,0.0,1.0};
GLfloat cyan[] = {0.0,1.0,1.0,1.0};
GLfloat yellow[] = {1.0,1.0,0.0,1.0};
GLfloat magenta[] = {1.0,0.0,1.0,1.0};
GLfloat tomato[] = {1.0,99.0/255.0,71.0/255.0,1.0};
GLfloat silver[] = {192.0/255.0,192.0/255.0,192.0/255.0,1.0};
GLfloat aquamarine[] = {112.0/255.0,219.0/255.0,147.0/255.0,1.0};
GLfloat red[] = {1.0,0.0,0.0,1.0};
GLfloat green[] = {0.0,1.0,0.0,1.0};
GLfloat blue[] = {0.0,0.0,1.0,1.0};
GLfloat tan_color[] = {219.0/255.0,147.0/255.0,112.0/255.0,1.0};
GLfloat coral[] = {1.0,127.0/255.0,80.0/255.0,1.0};
GLfloat lavender_purple[] = {150.0/255.0,123.0/255.0,182.0/255.0,1.0};
GLfloat light_indigo[] = {64.0/255.0,129.0/255.0,164.0/255.0,1.0};
GLfloat english_lavender[] = {180.0/255.0,131.0/255.0,149.0/255.0,1.0};
GLfloat roman_silver[] = {131.0/255.0,150.0/255.0,156.0/255.0,1.0};
GLfloat electric_crimson[] = {1.0,0.0,63.0/255.0,1.0};
GLfloat electric_lime[] = {204.0/255.0,1.0,0.0,1.0};

float base_width = 60.0;

angle_output angle_transformation;
output base_transformation[6];
smaller_output actuator_transformation[6];

GLint f_base[1][4] = { { 0,  1,  2,  3}};

GLfloat v_base[4][3] = {  { -base_width,  base_width,0.0 }, 
				      { base_width,  base_width, 0.0 },
					  { base_width, -base_width, 0.0 },
					{ -base_width, -base_width,0.0}};	

GLfloat n_base[1][3] = { {  0.0,  0.0,  1.0 }};

GLint f[12][4] = { { 0,  1,  2,  3},
				   { 1,  2,  5,  4},
				   { 4,  5,  3,  0},
				   { 6,  7,  8,  9},
				   { 7,  8, 11, 10},
				   { 6,  9, 11, 10},
				   { 1,  7,  6,  0},
				   { 0,  6, 10,  4},
				   { 4, 10,  7,  1},
				   { 2,  8,  9,  3},
				   { 3,  9, 11,  5},
				   { 5, 11,  8,  2} };

GLfloat v[12][3] = {  { -length_upper_new/2.0,  -d1new, thickness }, 
				      { 0.0,  d1new, thickness },
					  { 0.0, d1new - b, thickness },
					  { -length_upper_new/2.0 + a, -d1new+width, thickness },
					  {length_upper_new/2.0, -d1new, thickness },
					  {length_upper_new/2.0-a, -d1new+width, thickness  },
					  {-length_upper_new/2.0,  -d1new, 0.0 },
					  {0.0,  d1new, 0.0 },
					  { 0.0,  d1new-b, 0.0 },
					  { -length_upper_new/2.0 + a, -d1new+width, 0.0 },
					  {length_upper_new/2.0, -d1new, 0.0 },
					  {length_upper_new/2.0-a, -d1new+width, 0.0 } };

GLfloat n[12][3] = { {  0.0,  0.0,  -1.0 },
					 {  0.0,  0.0,  -1.0 },
					 {  0.0,  0.0,  -1.0 },
					 {  0.0,  0.0, 1.0 },
					 {  0.0,  0.0, 1.0 },
					 {  0.0,  0.0, 1.0 },
					 {  -cos(pi/6),  sin(pi/6),  0.0 },
					 {  0.0, -1.0,  0.0 },
					 {  cos(pi/6),  sin(pi/6),  0.0 },
					 {  cos(pi/6),  -sin(pi/6),  0.0 },
					 {  0.0,  1.0,  0.0 },
					 {  -cos(pi/6), -sin(pi/6),  0.0 } };

void draw_base(void)
{
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);

	glMaterialfv(GL_FRONT, GL_DIFFUSE, tomato);
	glBegin(GL_QUADS);
			glNormal3fv(&n_base[0][0]);
			glVertex3fv(&v_base[f_base[0][0]][0]);
			glVertex3fv(&v_base[f_base[0][1]][0]);
			glVertex3fv(&v_base[f_base[0][2]][0]);
			glVertex3fv(&v_base[f_base[0][3]][0]);
		glEnd();

}

void draw_bermuda_triangle(float sway, float surge, float heave, float yaw, float pitch, float roll)
{
	static int print = 0;
	LocalToVehicle(sway, surge, heave, yaw, pitch, roll);
	
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();

	glTranslatef(center_of_rotation_x,center_of_rotation_y,center_of_rotation_z);
	glTranslatef(sway,surge,heave);
	glRotatef(90,0.0,1.0,0.0);
	glRotatef(angle_transformation.a[0][0]*180.0/pi,0.0,0.0,1.0);
	glRotatef(-90,1.0,0.0,0.0);
	glRotatef(angle_transformation.a[1][0]*180.0/pi,0.0,0.0,1.0);
	glTranslatef(-center_to_frame3_dist,0.0,0.0);
	glRotatef(90,0.0,1.0,0.0);
	glRotatef(angle_transformation.a[2][0]*180.0/pi,0.0,0.0,1.0);

	
	if ( print )
	{
		printf("%f , %f\r\n",center_of_rotation_z,center_to_frame3_dist);
		print = 0;
	}
	glRotatef(90,0.0,0.0,1.0);
	
	glMaterialfv(GL_FRONT, GL_DIFFUSE, light_indigo);
	for (int i = 0; i < 12; i++)
	{
		glBegin(GL_QUADS);
			glNormal3fv(&n[i][0]);
			glVertex3fv(&v[f[i][0]][0]);
			glVertex3fv(&v[f[i][1]][0]);
			glVertex3fv(&v[f[i][2]][0]);
			glVertex3fv(&v[f[i][3]][0]);
		glEnd();
	}
	glRotatef(-90,0.0,0.0,1.0);
	draw_arrows();

	glPopMatrix();

	//draw_arrows(transformation.P[0][0],transformation.P[1][0],transformation.P[2][0],transformation.angle_of_rotation,transformation.axis_of_rotation[0][0],transformation.axis_of_rotation[1][0],transformation.axis_of_rotation[2][0]);
	
}

void draw_center_of_rotation(float sway, float surge, float heave)
{
	
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, magenta);
	glPushMatrix();
	glTranslatef(center_of_rotation_x,center_of_rotation_y,center_of_rotation_z);
	glTranslatef(sway,surge,heave);
	glutSolidSphere(1.5,50,50);
	glPopMatrix();
}

void draw_center_of_translation()
{
	
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, electric_crimson);
	glPushMatrix();
	glTranslatef(center_of_rotation_x,center_of_rotation_y,center_of_rotation_z);
	glutSolidSphere(1.5,50,50);
	glPopMatrix();
}

void draw_world_coord(void)
{
	
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();

	/* z-arrow */
	glMaterialfv(GL_FRONT, GL_DIFFUSE, red);
	arrow();

	glMaterialfv(GL_FRONT, GL_DIFFUSE, green);
	glRotatef(90,0.0,1.0,0.0);
	arrow();

	glMaterialfv(GL_FRONT, GL_DIFFUSE, blue);
	glRotatef(-90,1.0,0.0,0.0);
	arrow();

	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glPopMatrix();

}

void draw_arrows(void)
{
	
	//LocalToVehicle(sway, surge, heave, yaw, pitch, roll);

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	//glPushMatrix();

	/* z-arrow */
	
	//glRotatef(angleY,0,1,0);
	//glRotatef(angleZ,0,0,1);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, red);
	arrow();

	glMaterialfv(GL_FRONT, GL_DIFFUSE, green);
	glRotatef(90,0.0,1.0,0.0);
	arrow();

	glMaterialfv(GL_FRONT, GL_DIFFUSE, blue);
	glRotatef(-90,1.0,0.0,0.0);
	arrow();

	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	//glPopMatrix();

}

void arrow(void)
{

	GLfloat base[1000][3];
	GLfloat body[1000][3];
	GLfloat neck[1000][3];
	GLfloat tip[1000][3];
	float Cx = 0.0, Cy = 0.0;
	float interval = 1.0/999.0;
	GLfloat normalA[1000][3]; // For all vertical cylindrical surfaces
	GLfloat normalB[1000][3]; // For all angled/slanted surfaces
	float r = 0.25;
	float neck_r = 0.5;

	for(int i = 0; i < 1000; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(j == 0)
			{
				base[i][j] = Cx + r*cos((interval)*i*2.0*pi);
				body[i][j] = Cx + r*cos((interval)*i*2.0*pi);
				neck[i][j] = Cx + neck_r*cos((interval)*i*2.0*pi);
				tip[i][j] = Cx + 0.001*r*cos((interval)*i*2.0*pi);
			}
			if(j == 1)
			{
				base[i][j] = Cy + r*sin((interval)*i*2.0*pi);
				body[i][j] = Cy + r*sin((interval)*i*2.0*pi);
				neck[i][j] = Cy + neck_r*sin((interval)*i*2.0*pi);
				tip[i][j] = Cy + 0.001*r*sin((interval)*i*2.0*pi);
			}
			if(j == 2)
			{
				base[i][j] = 0;
				body[i][j] = 4;
				neck[i][j] = 4;
				tip[i][j] = 6;
			}
		}
	}


	for(int i = 0; i < 999; i++)
		{
			normalA[i][2] = 0;
			normalB[i][2] = cos(atan(2.0));
			if((interval*i*2.0*pi >= 0) && (interval*i*2.0*pi < pi/2.0))
			{
				normalA[i][0] = sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][0] = sin(atan(2.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][1] = sin(atan(2.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= pi/2.0) && (interval*i*2.0*pi < pi))
			{
				normalA[i][0] = -sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][0] = -sin(atan(2.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][1] = sin(atan(2.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= pi) && (interval*i*2.0*pi < 3.0*pi/2.0))
			{
				normalA[i][0] = -sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = -cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][0] = -sin(atan(2.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][1] = -sin(atan(2.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= 3.0*pi/2.0) && (interval*i*2.0*pi < 2.0*pi))
			{
				normalA[i][0] = sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = -cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][0] = sin(atan(2.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalB[i][1] = -sin(atan(2.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
		}

	/* arrow Base */
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0,0.0,-1.0);
		for(int k = 0; k < 1000; k++)
		{
			glVertex3fv(&base[k][0]);
		}
	glEnd();

	/* arrow Body */
	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			glNormal3fv(&normalA[k][0]);
			glVertex3fv(&base[k][0]);
			glVertex3fv(&base[k+1][0]);
			glVertex3fv(&body[k+1][0]);
			glVertex3fv(&body[k][0]);
		}
	glEnd();

	/* arrow Neck */
	glBegin(GL_QUADS);
	glNormal3f(0.0,0.0,-1.0);
		for(int k = 0; k < 999; k++)
		{
			glVertex3fv(&body[k][0]);
			glVertex3fv(&body[k+1][0]);
			glVertex3fv(&neck[k+1][0]);
			glVertex3fv(&neck[k][0]);
		}
	glEnd();

	/* arrow Tip */
	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			glNormal3fv(&normalB[k][0]);
			glVertex3fv(&neck[k][0]);
			glVertex3fv(&neck[k+1][0]);
			glVertex3fv(&tip[k+1][0]);
			glVertex3fv(&tip[k][0]);
		}
	glEnd();

}

void draw_actuators(void)
{
	int i;
	static int print = 1;

	LocalToBaseAndActuator(actuator_chassis);
	
	if ( print )
		{
			for ( i = 0; i < 6; i++ )
			{
				printf("Stage 1\r\n");
				for( int k = 0; k < 2; k++)
				{
					printf("%f ",base_transformation[i].angle_of_rotation[0][k]);
				}
				printf("\r\n");
			}
		}
	print = 0;
		
	//ActuatorChassis(base_transformation[0].P[0][0],base_transformation[0].P[1][0],base_transformation[0].P[2][0],base_transformation[0].angle_of_rotation[0][0],base_transformation[0].angle_of_rotation[0][1]);
		//ActuatorRods(base_transformation[0].P[0][0],base_transformation[0].P[1][0],base_transformation[0].P[2][0],base_transformation[0].angle_of_rotation[0][0],base_transformation[0].angle_of_rotation[0][1],actuator_transformation[0].stroke);
		
	for ( i = 0; i < 6; i++ )
	{
		ActuatorChassis(base_transformation[i].P[0][0],base_transformation[i].P[1][0],base_transformation[i].P[2][0],base_transformation[i].angle_of_rotation[0][0],base_transformation[i].angle_of_rotation[0][1]);
		ActuatorRods(base_transformation[i].P[0][0],base_transformation[i].P[1][0],base_transformation[i].P[2][0],base_transformation[i].angle_of_rotation[0][0],base_transformation[i].angle_of_rotation[0][1],actuator_transformation[i].stroke);
	
		//ActuatorChassis(base_transformation[i].P[0][0],base_transformation[i].P[1][0],base_transformation[i].P[2][0],base_transformation[i].angle_of_rotation,base_transformation[i].axis_of_rotation[0][0],base_transformation[i].axis_of_rotation[1][0],base_transformation[i].axis_of_rotation[2][0]);
		//ActuatorRods(base_transformation[i].P[0][0],base_transformation[i].P[1][0],base_transformation[i].P[2][0],base_transformation[i].angle_of_rotation,base_transformation[i].axis_of_rotation[0][0],base_transformation[i].axis_of_rotation[1][0],base_transformation[i].axis_of_rotation[2][0],actuator_transformation[i].stroke);
	}

}

void ActuatorChassis(float Px, float Py, float Pz, float thetaA, float thetaB)
{
	const float radius = 2.0;
	static int switch_colour = 1;
	GLfloat neck[1000][3];
	GLfloat tip[1000][3];
	
	float h1 = 0.7*actuator_chassis;
	float h2 = 0.2*actuator_chassis;
	float h3 = actuator_chassis - h1 - h2;
	float neck_radius = h3*(radius/(h2+h3));

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();

	glTranslatef(Px,Py,Pz);
	//glRotatef(90.0,0.0, 1.0, 0.0);
	glRotatef(thetaA*180.0/pi,0.0, 0.0, 1.0);
	glRotatef(90.0-thetaB*180.0/pi,0.0, 1.0, 0.0);

	GLfloat base[1000][3];
	GLfloat body[1000][3];
	float Cx = 0.0, Cy = 0.0;
	float interval = 1.0/999.0;
	GLfloat normalA[1000][3]; // For all vertical cylindrical surfaces
	GLfloat normalC[1000][3]; // For all angled/slanted surfaces

	for(int i = 0; i < 1000; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(j == 0) // X- coordinates
			{
				base[i][j] = Cx + radius*cos((interval)*i*2.0*pi);
				body[i][j] = Cx + radius*cos((interval)*i*2.0*pi);
				neck[i][j] = Cx + neck_radius*cos((interval)*i*2.0*pi);
				tip[i][j]  = Cx + 0.001*radius*cos((interval)*i*2.0*pi);
			}
			if(j == 1) // Y- coordinates
			{
				base[i][j] = Cy + radius*sin((interval)*i*2.0*pi);
				body[i][j] = Cy + radius*sin((interval)*i*2.0*pi);
				neck[i][j] = Cy + neck_radius*sin((interval)*i*2.0*pi);
				tip[i][j]  = Cy + 0.001*radius*sin((interval)*i*2.0*pi);
			}
			if(j == 2) // Z- coordinates
			{
				base[i][j] = actuator_chassis;
				body[i][j] = actuator_chassis - h1;
				neck[i][j] = actuator_chassis - h1 - h2;
				tip[i][j]  = 0;
			}
		}
	}


	for(int i = 0; i < 999; i++)
		{
			normalA[i][2] = 0;
			normalC[i][2] = -cos(atan(1.0));
			if((interval*i*2.0*pi >= 0) && (interval*i*2.0*pi < pi/2.0))
			{
				normalA[i][0] = sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= pi/2.0) && (interval*i*2.0*pi < pi))
			{
				normalA[i][0] = -sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = -sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= pi) && (interval*i*2.0*pi < 3.0*pi/2.0))
			{
				normalA[i][0] = -sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = -cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = -sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = -sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= 3.0*pi/2.0) && (interval*i*2.0*pi < 2.0*pi))
			{
				normalA[i][0] = sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = -cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = -sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
		}

	/* Actuator Base */
	
	glMaterialfv(GL_FRONT, GL_DIFFUSE, yellow);
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0,0.0,1.0);
		for(int k = 0; k < 1000; k++)
		{
			glVertex3fv(&base[k][0]);
		}
	glEnd();

	/* Actuator Body */
	
	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			if ( (k % 100) == 0 )
			{
				switch_colour *=-1;
			}

			if ( switch_colour > 0 )
			{
				glMaterialfv(GL_FRONT, GL_DIFFUSE, black);
			}
			else
			{
				glMaterialfv(GL_FRONT, GL_DIFFUSE, yellow);
			}
			glNormal3fv(&normalA[k][0]);
			glVertex3fv(&base[k][0]);
			glVertex3fv(&base[k+1][0]);
			glVertex3fv(&body[k+1][0]);
			glVertex3fv(&body[k][0]);
		}
	glEnd();
	
	// Actuator Neck
	glMaterialfv(GL_FRONT, GL_DIFFUSE, tan_color);
	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			glNormal3fv(&normalC[k][0]);
			glVertex3fv(&body[k][0]);
			glVertex3fv(&body[k+1][0]);
			glVertex3fv(&neck[k+1][0]);
			glVertex3fv(&neck[k][0]);
		}
	glEnd();

	/* ACtuator Tip */
	glMaterialfv(GL_FRONT, GL_DIFFUSE, black);
	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			glNormal3fv(&normalC[k][0]);
			glVertex3fv(&neck[k][0]);
			glVertex3fv(&neck[k+1][0]);
			glVertex3fv(&tip[k+1][0]);
			glVertex3fv(&tip[k][0]);
		}
	glEnd();

	/*glMaterialfv(GL_FRONT, GL_DIFFUSE, black);
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0,0.0,1.0);
		for(int k = 0; k < 1000; k++)
		{
			glVertex3fv(&body[k][0]);
		}
	glEnd();*/

	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glPopMatrix();
	
}


void ActuatorRods(float Px, float Py, float Pz, float thetaA, float thetaB, float stroke_length)
{
	const float radius = 0.5;
	GLfloat tip[1000][3];
	GLfloat normalC[1000][3]; // For all angled/slanted surfaces

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();

	glTranslatef(Px,Py,Pz);
	//glRotatef(90.0,0.0, 1.0, 0.0);
	//glRotatef(-thetaA*180.0/pi,1.0, 0.0, 0.0);
	glRotatef(thetaA*180.0/pi,0.0, 0.0, 1.0);
	glRotatef(90.0-thetaB*180.0/pi,0.0, 1.0, 0.0);
	glTranslatef(0.0,0.0,actuator_chassis);

	GLfloat base[1000][3];
	GLfloat body[1000][3];
	float Cx = 0.0, Cy = 0.0;
	float interval = 1.0/999.0;
	GLfloat normalA[1000][3]; // For all vertical cylindrical surfaces

	for(int i = 0; i < 1000; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(j == 0) // X- coordinates
			{
				base[i][j] = Cx + radius*cos((interval)*i*2.0*pi);
				body[i][j] = Cx + radius*cos((interval)*i*2.0*pi);
				tip[i][j]  = Cx + 0.001*radius*cos((interval)*i*2.0*pi);
			}
			if(j == 1) // Y- coordinates
			{
				base[i][j] = Cy + radius*sin((interval)*i*2.0*pi);
				body[i][j] = Cy + radius*sin((interval)*i*2.0*pi);
				tip[i][j]  = Cy + 0.001*radius*sin((interval)*i*2.0*pi);
			}
			if(j == 2) // Z- coordinates
			{
				base[i][j] = 0.0;
				body[i][j] = 0.85*stroke_length;
				tip[i][j]  = stroke_length;
			}
		}
	}


	for(int i = 0; i < 999; i++)
		{
			normalA[i][2] = 0;
			normalC[i][2] = -cos(atan(1.0));
			if((interval*i*2.0*pi >= 0) && (interval*i*2.0*pi < pi/2.0))
			{
				normalA[i][0] = sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= pi/2.0) && (interval*i*2.0*pi < pi))
			{
				normalA[i][0] = -sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = -sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= pi) && (interval*i*2.0*pi < 3.0*pi/2.0))
			{
				normalA[i][0] = -sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = -cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = -sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = -sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
			if((interval*i*2.0*pi >= 3.0*pi/2.0) && (interval*i*2.0*pi < 2.0*pi))
			{
				normalA[i][0] = sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalA[i][1] = -cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][0] = sin(atan(1.0))*sin(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
				normalC[i][1] = -sin(atan(1.0))*cos(abs(atan((base[i+1][1] - base[i][1]) / (base[i+1][0] - base[i][0]))));
			}
		}

	/* Rod Base */

	glMaterialfv(GL_FRONT, GL_DIFFUSE, roman_silver);
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0,0.0,-1.0);
		for(int k = 0; k < 1000; k++)
		{
			glVertex3fv(&base[k][0]);
		}
	glEnd();

	/* Rod Body */
	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			glNormal3fv(&normalA[k][0]);
			glVertex3fv(&base[k][0]);
			glVertex3fv(&base[k+1][0]);
			glVertex3fv(&body[k+1][0]);
			glVertex3fv(&body[k][0]);
		}
	glEnd();

	glBegin(GL_QUADS);
		for(int k = 0; k < 999; k++)
		{
			glNormal3fv(&normalC[k][0]);
			glVertex3fv(&body[k][0]);
			glVertex3fv(&body[k+1][0]);
			glVertex3fv(&tip[k+1][0]);
			glVertex3fv(&tip[k][0]);
		}
	glEnd();

	/* Rod Top */
	/*glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0,0.0,1.0);
		for(int k = 0; k < 1000; k++)
		{
			glVertex3fv(&body[k][0]);
		}
	glEnd();*/



	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glPopMatrix();
	
}

