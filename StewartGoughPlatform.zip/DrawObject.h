#pragma once
#include <iostream>

#include <windows.h>
#include <gl/GL.h>
#include <gl/GLU.h>
#include <gl/glut.h>
#include <gl/glext.h>
#include <gl/wglext.h>
#include<vector>
using namespace std;

void ActuatorChassis(float Px, float Py, float Pz, float thetaA, float thetaB);

void arrow(void);

void draw_arrows(void);

void draw_world_coord(void);

void draw_bermuda_triangle(float sway, float surge, float heave, float yaw, float pitch, float roll);

void draw_center_of_rotation(float sway, float surge, float heave);

void draw_center_of_translation();

void ActuatorRods(float Px, float Py, float Pz, float thetaA, float thetaB, float stroke_length);

void draw_actuators(void);

void draw_base(void);