/*
ComS 577 Graduate Project
Author: Dao Yan Lim
Date: 12/10/2015
Note: Everything in this program is written by the author except for 'trackball'.
      Trackball was taken from the class HCI571X. User must ask the permission of the instructor
	  of the class in order to use or distribute it.
*/

#include <iostream>

#if defined(__APPLE__) || defined(MACOSX)
    #include <GLUT/glut.h>
    #include <OpenGL/gl.h>
    #include <OpenGL/glu.h>
#else
    #include <windows.h>
    #include <gl/gl.h>
    #include <gl/glu.h>
    #include <gl/glut.h>
#endif

#include "math.h"
#include <stdio.h>
#include <iomanip>  
#include "Trackball.h"
#include "DrawObject.h"
#include "matrixOperation.h"
#include "stddef.h"
#include "stdlib.h"
#include "string.h"
#include "Transformation.h"

const long double pi = 3.141592653589793238L;


GLfloat light_diffuse[] = {1.0, 0.0, 0.0, 1.0};  /* Red diffuse light. */
GLfloat light_position[] = {1.0, 1.0, 1.0, 0.0};  /* Infinite light location. */

float g_eye[3] = {0, 0, 100};

float g_quat[4] = {0.0, 0.0, 0.0, 0.0};
float g_last[4] = {0.0, 0.0, 0.0, 0.0};

float g_previousMouseX = 0.0f;
float g_previousMouseY = 0.0f;

float window_width = 800;
float window_height = 800;

int g_sequence = 0;

static float angle = 0;

static int point = 0;

static bool change_phase = FALSE;

float wn_yaw	      = 1.0;
float wn_pitch		  = 2.0;
float wn_roll         = 1.5;
float wn_heave        = 1.0;
float wn_surge		  = 1.0;
float wn_sway         = 1.0;
float yaw_amplitude   = 8.0*pi/180.0;
float pitch_amplitude = 10.0*pi/180.0;
float roll_amplitude  = 12.0*pi/180.0;
float heave_amplitude = 5.0;
float surge_amplitude = 4.0;
float sway_amplitude  = 6.0;

float TIME = 0.0;

typedef struct
{
	float sway;
	float surge;
	float heave;
	float yaw;
	float pitch;
	float roll;
}motion;

motion vehicle;

void Animation(int value)
{
	
	vehicle.sway  = sway_amplitude*cos(wn_sway*TIME);
	vehicle.surge = surge_amplitude*sin(wn_surge*TIME);
	vehicle.heave = heave_amplitude*sin(wn_heave*TIME);
	vehicle.yaw   = yaw_amplitude*sin(wn_yaw*TIME);
	vehicle.pitch = pitch_amplitude*sin(wn_pitch*TIME);
	vehicle.roll  = roll_amplitude*sin(wn_roll*TIME);

	//vehicle.roll  = roll_amplitude;	

	TIME         += 0.01;
	glutPostRedisplay();
	glutTimerFunc(2,Animation,0);

}

void camera_MotionFunc(int x, int y)
{
     // This scales the mouse coordinates to a range of [-1, 1]
    float px1 = (window_width -x)/(window_width/2.0) - 1.0;
    float py1 = y/(window_height/2.0) - 1.0;

     // Call the trackball function to get the new quaternion
    trackball(g_last, px1, py1, g_previousMouseX, g_previousMouseY);
    
    // Add the new quaternion to the current orientation.
    add_quats(g_last, g_quat,  g_quat);

    // Save the mouse position for the next step.
    g_previousMouseX = px1;
    g_previousMouseY = py1;
      
    // update the display and the objects in the scene
    glutPostRedisplay();
}


void camera_MouseButtonFunc(int button, int state, int x, int y)
{
    switch(state)
    {
        case GLUT_DOWN:
        {
            // This scales the mouse coordinates to a range of [-1, 1]
            float px1 = (window_width -x)/(window_width/2.0) - 1.0;
            float py1 = y/(window_height/2.0) - 1.0;

            // Store the mouse position as previous position.
            g_previousMouseX = px1;
            g_previousMouseY = py1;
            break;
        }
        case GLUT_UP:

            break;
    }

}

void init_camera(void)
{

    /* Setup the view of the cube. */
    glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
    gluPerspective( /* field of view in degree */ 100.0,
      /* aspect ratio */ 1.0,
      /* Z near */ 1.0, /* Z far */ 1000.0);

    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    gluLookAt(100, 100, 100.0,  /* eye is at (0,0,5) */
      0.0, 0.0, 0.0,      /* center is at (0,0,0) */
      1.0, 0.0, 0.0);      /* up is in positive Y direction */
}

void updateCamera(void)
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(-g_eye[0], -g_eye[1], -g_eye[2]);
	GLfloat m[4][4];
	build_rotmatrix(m, g_quat);
	glMultMatrixf(&m[0][0]);
}

void display(void)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  updateCamera();
  //drawBox();
  draw_base();
  draw_bermuda_triangle(vehicle.sway, vehicle.surge, vehicle.heave, vehicle.yaw, vehicle.pitch, vehicle.roll);
  draw_world_coord();
 // draw_arrows(0.0,0.0,0.0,0.0,0.0,0.0,0.0);
  draw_center_of_translation();
  draw_center_of_rotation(vehicle.sway, vehicle.surge, vehicle.heave);
  draw_actuators();
  glutSwapBuffers();
}


void init_light(void)
{
	glEnable(GL_LIGHTING);
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);

	GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat light_position[] = {3.0, 3.0, 3.0, 0.0};

	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	GLfloat light_position1[] = {-3.0, 3.0, 3.0, 0.0};

	glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT1, GL_POSITION, light_position1);
}


void init(void)
{

	init_light();
	glClearColor(1.0,1.0,1.0,0.0);
	trackball(g_quat, 0.0, 0.0, 0.0, 0.0);
	init_camera();
	glEnable(GL_DEPTH_TEST);

}


int main(int argc, char **argv)
{


		glutInit(&argc, argv);
		glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
		glutInitWindowSize(800,800);
		glutInitWindowPosition(100,100);
		glutCreateWindow("StewartGoughPlatform");
		glutDisplayFunc(display);
		init();

		glutMouseFunc(camera_MouseButtonFunc);
		glutMotionFunc(camera_MotionFunc);
		glutTimerFunc(2,Animation,0);
		glutMainLoop();


  return 0;
}
