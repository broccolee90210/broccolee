clear all
close all
clc

%% ComS 577 Graduate Project 
% Dao Yan Lim
% 12/10/2015

PlotReferenceFrames = false; % change these to true to view static and dynamic simulation of the platform
animation = false;

syms theta
Rz = [cos(theta) -sin(theta) 0;sin(theta) cos(theta) 0;0 0 1];
Ry = [cos(theta) 0 sin(theta);0 1 0;-sin(theta) 0 cos(theta)];
Rx = [1 0 0;0 cos(theta) -sin(theta);0 sin(theta) cos(theta)];


%% Local to Vehicle frame (Euler Angle: Y-P-R)
syms theta_yaw theta_pitch theta_roll
RotMatEuler         = simple(subs(Rz,theta,theta_yaw)*subs(Ry,theta,theta_pitch)*subs(Rx,theta,theta_roll));
LocalToVehicleEuler = [0 1 0;1 0 0;0 0 -1]*RotMatEuler;


%% Local to Vehicle frame (6 d.o.f)
syms x y z rotation_center_z rotation_center_y rotation_center_x l2 heave sway surge theta1 theta2 theta3
Translation      = [eye(3) [x;y;z];0 0 0 1];
LocalToFrameT1   = subs(Translation,{x,y,z},{rotation_center_x,rotation_center_y,rotation_center_z});
FrameT1ToFrameT2 = subs(Translation,{x,y,z},{sway,surge,heave});
FrameT2ToFrameR1 = [[0 0 1;0 1 0;-1 0 0]*subs(Rz,theta,theta1) [0;0;0];0 0 0 1];
FrameR1ToFrameR2 = [double(subs(Rx,theta,-pi/2))*subs(Rz,theta,theta2) [0;0;0];0 0 0 1];
FrameR2ToFrameR3 = subs(Translation,{x,y,z},{-l2,0,0})*[[0 0 1;0 1 0;-1 0 0]*subs(Rz,theta,theta3) [0;0;0];0 0 0 1];
LocalToCenter    = simple(LocalToFrameT1*FrameT1ToFrameT2); % No rotational components yet
CenterToVehicle  = simple(FrameT2ToFrameR1*FrameR1ToFrameR2*FrameR2ToFrameR3); % Consists rotational components
LocalToVehicle   = simple(LocalToCenter*CenterToVehicle);

% These are solutions of theta1 - theta3
theta1_sol = atan(-LocalToVehicleEuler(2,3)/LocalToVehicleEuler(3,3));
theta2_sol = asin(-LocalToVehicleEuler(1,3));
theta3_sol = atan(LocalToVehicleEuler(1,1)/LocalToVehicleEuler(1,2));
CenterToVehicle2 = subs(CenterToVehicle,{theta1,theta2,theta3},{theta1_sol,theta2_sol,theta3_sol});


%% Plot the reference frames

orig             = [0;0;0;1];
xVec             = [3;0;0;1];
yVec             = [0;3;0;1];
zVec             = [0;0;3;1];

linkSize         = 1;
linkColor        = 'k';
VectorLineWidth  = 2;
xVectorColorLine = 'r';
yVectorColorLine = 'g';
zVectorColorLine = 'b';
xmin             = -80;
xmax             = 80;
ymin             = -80;
ymax             = 80;
zmin             = -0;
zmax             = 60;
viewX            = 1;
viewY            = 1;
viewZ            = 1;

% Set and Substitute Parameters

j                = 1;
h                = 1;
SaveMatrix       = [];
Extra            = 22;          % How many additional links/frames after one full links description.

if(PlotReferenceFrames == true)
    
initial_yaw           = 0*pi/180;
initial_pitch         = 0*pi/180;
initial_roll          = 0*pi/180;
center_x              = 10;
center_y              = -10;
center_z              = 30;
home_height           = 40;
center_to_frame3_dist = home_height - center_z;
initial_sway          = 0;
initial_surge         = 0;
initial_heave         = 0;

theta1New = double(subs(theta1_sol,{theta_yaw,theta_pitch,theta_roll},{initial_yaw,initial_pitch,initial_roll}));
theta2New = double(subs(theta2_sol,{theta_yaw,theta_pitch,theta_roll},{initial_yaw,initial_pitch,initial_roll}));
theta3New = double(subs(theta3_sol,{theta_yaw,theta_pitch,theta_roll},{initial_yaw,initial_pitch,initial_roll}));

LocalToCenterNew   = double(subs(LocalToCenter,{rotation_center_x,rotation_center_y,rotation_center_z,sway,surge,heave},{center_x,center_y,center_z,initial_sway,initial_surge,initial_heave}));
CenterToVehicleNew = double(subs(CenterToVehicle2,{theta_yaw,theta_pitch,theta_roll,l2},{initial_yaw,initial_pitch,initial_roll,center_to_frame3_dist}));
LocalToVehicleNew  = LocalToCenterNew*CenterToVehicleNew;


length_upper = 50;
length_lower = length_upper*2;
d1           = sqrt(length_upper^2 - (length_upper/2)^2)/2;
d2           = sqrt(length_lower^2 - (length_lower/2)^2)/2;

% - Platfrom points
P_front_left_lower_x     = -length_upper;
P_front_left_lower_y     = d2;
P_front_right_lower_x    = length_upper;
P_front_right_lower_y    = d2;
P_back_lower_y           = -d2;
P_front_upper_prime      = LocalToVehicleNew*double(subs(Translation,{x,y,z},{-d1,0,0}));
P_front_upper            = P_front_upper_prime(1:3,4);
P_back_left_upper_prime  = LocalToVehicleNew*double(subs(Translation,{x,y,z},{d1,length_upper/2,0}));
P_back_left_upper        = P_back_left_upper_prime(1:3,4);
P_back_right_upper_prime = LocalToVehicleNew*double(subs(Translation,{x,y,z},{d1,-length_upper/2,0}));
P_back_right_upper       = P_back_right_upper_prime(1:3,4);
P_front_left_lower       = [P_front_left_lower_x;P_front_left_lower_y;0];
P_front_right_lower      = [P_front_right_lower_x;P_front_right_lower_y;0];
P_back_lower             = [0;P_back_lower_y;0];

% - Linear actuator lengths
La1 = norm(P_front_upper - P_front_left_lower);
La2 = norm(P_back_left_upper - P_front_left_lower);
La3 = norm(P_back_left_upper - P_back_lower);
La4 = norm(P_back_right_upper - P_back_lower);
La5 = norm(P_back_right_upper - P_front_right_lower);
La6 = norm(P_front_upper - P_front_right_lower);
La_chassis = 30;

% - Linear actuator angles
diff_xa1 = -(P_front_left_lower(1) - P_front_upper(1));
diff_ya1 = -(P_front_left_lower(2) - P_front_upper(2));
diff_za1 = -(P_front_left_lower(3) - P_front_upper(3));
theta_a1 = atan(diff_ya1/diff_xa1);
theta_b1 = atan(abs(diff_za1)/norm([diff_xa1 diff_ya1]));

diff_xa2 = -(P_front_left_lower(1) - P_back_left_upper(1));
diff_ya2 = -(P_front_left_lower(2) - P_back_left_upper(2));
diff_za2 = -(P_front_left_lower(3) - P_back_left_upper(3));
theta_a2 = atan(diff_ya2/diff_xa2);
theta_b2 = atan(abs(diff_za2)/norm([diff_xa2 diff_ya2]));

diff_xa3 = -(P_back_lower(1) - P_back_left_upper(1));
diff_ya3 = -(P_back_lower(2) - P_back_left_upper(2));
diff_za3 = -(P_back_lower(3) - P_back_left_upper(3));
theta_a3 = pi+atan(diff_ya3/diff_xa3);
theta_b3 = atan(abs(diff_za3)/norm([diff_xa3 diff_ya3]));

diff_xa4 = -(P_back_lower(1) - P_back_right_upper(1));
diff_ya4 = -(P_back_lower(2) - P_back_right_upper(2));
diff_za4 = -(P_back_lower(3) - P_back_right_upper(3));
theta_a4 = atan(diff_ya4/diff_xa4);
theta_b4 = atan(abs(diff_za4)/norm([diff_xa4 diff_ya4]));

diff_xa5 = -(P_front_right_lower(1) - P_back_right_upper(1));
diff_ya5 = -(P_front_right_lower(2) - P_back_right_upper(2));
diff_za5 = -(P_front_right_lower(3) - P_back_right_upper(3));
theta_a5 = pi+atan(diff_ya5/diff_xa5);
theta_b5 = atan(abs(diff_za5)/norm([diff_xa5 diff_ya5]));

diff_xa6 = -(P_front_right_lower(1) - P_front_upper(1));
diff_ya6 = -(P_front_right_lower(2) - P_front_upper(2));
diff_za6 = -(P_front_right_lower(3) - P_front_upper(3));
theta_a6 = pi+atan(diff_ya6/diff_xa6);
theta_b6 = atan(abs(diff_za6)/norm([diff_xa6 diff_ya6]));

% - Actuator Transformations
LocalToActuatorBase_1   = double(subs(Translation,{x,y,z},{P_front_left_lower(1),P_front_left_lower(2),P_front_left_lower(3)}));
ActuatorBaseToChassis_1 = [double(subs(Rz,theta,theta_a1))*double(subs(Ry,theta,-theta_b1)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
ChassisToStrokeTip_1    = double(subs(Translation,{x,y,z},{La1-La_chassis,0,0}));

LocalToActuatorBase_2   = double(subs(Translation,{x,y,z},{P_front_left_lower(1),P_front_left_lower(2),P_front_left_lower(3)}));
ActuatorBaseToChassis_2 = [double(subs(Rz,theta,theta_a2))*double(subs(Ry,theta,-theta_b2)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
ChassisToStrokeTip_2    = double(subs(Translation,{x,y,z},{La2-La_chassis,0,0}));

LocalToActuatorBase_3   = double(subs(Translation,{x,y,z},{P_back_lower(1),P_back_lower(2),P_back_lower(3)}));
ActuatorBaseToChassis_3 = [double(subs(Rz,theta,theta_a3))*double(subs(Ry,theta,-theta_b3)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
ChassisToStrokeTip_3    = double(subs(Translation,{x,y,z},{La3-La_chassis,0,0}));

LocalToActuatorBase_4   = double(subs(Translation,{x,y,z},{P_back_lower(1),P_back_lower(2),P_back_lower(3)}));
ActuatorBaseToChassis_4 = [double(subs(Rz,theta,theta_a4))*double(subs(Ry,theta,-theta_b4)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
ChassisToStrokeTip_4    = double(subs(Translation,{x,y,z},{La4-La_chassis,0,0}));

LocalToActuatorBase_5   = double(subs(Translation,{x,y,z},{P_front_right_lower(1),P_front_right_lower(2),P_front_right_lower(3)}));
ActuatorBaseToChassis_5 = [double(subs(Rz,theta,theta_a5))*double(subs(Ry,theta,-theta_b5)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
ChassisToStrokeTip_5    = double(subs(Translation,{x,y,z},{La5-La_chassis,0,0}));

LocalToActuatorBase_6   = double(subs(Translation,{x,y,z},{P_front_right_lower(1),P_front_right_lower(2),P_front_right_lower(3)}));
ActuatorBaseToChassis_6 = [double(subs(Rz,theta,theta_a6))*double(subs(Ry,theta,-theta_b6)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
ChassisToStrokeTip_6    = double(subs(Translation,{x,y,z},{La6-La_chassis,0,0}));


Matrix   = [eye(4);LocalToCenterNew;CenterToVehicleNew];  % Full link descriptions are saved in this matrix.
TMatrix  = Matrix(1:4,:);
origOld  = orig;

for i = 1:(length(Matrix)/length(LocalToCenterNew) + Extra)
    
    if ( i <= length(Matrix)/length(LocalToCenterNew) )
        
        for k = 1:i            

            if (i - k == 1)
                TMatrix = TMatrix*Matrix(j:j+3,:);
            end

        end
    
     % Let's plot the additional links/frames, if they are any    
     % - Actuator 1
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 1 )   
        
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_1;
        origOld       = [P_front_left_lower;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 2 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_1;

         
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 3 )

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_1;
        
    % - Actuator 2
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 4 )  
        
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_2;
        origOld       = [P_front_left_lower;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 5 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_2;
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 6 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_2;
        
    % - Actuator 3
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 7 )  
        
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_3;
        origOld       = [P_back_lower;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 8 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_3;
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 9 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_3;
        
    % - Actuator 4
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 10 )  
        
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_4;
        origOld       = [P_back_lower;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 11 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_4;
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 12 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_4;
        
    % - Actuator 5
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 13 )  
        
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_5;
        origOld       = [P_front_right_lower;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 14 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_5;
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 15 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_5;
        
    % - Actuator 6
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 16 )  
        
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_6;
        origOld       = [P_front_right_lower;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 17 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_6;
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 18 ) 

        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_6;
        
    % - Upper Triangle
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 19 ) 
        TMatrix       = SaveMatrix( 1:4, : ) * LocalToVehicleNew * double(subs(Translation,{x,y,z},{-d1,0,0}));
        orig = [0;0;0;1];
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 20 ) 
        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * double(subs(Translation,{x,y,z},{d1*2,-length_upper/2,0}));
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 21 ) 
        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * double(subs(Translation,{x,y,z},{0,length_upper,0}));
        
    elseif (i == length(Matrix)/length(LocalToCenterNew) + 22 ) 
        TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * double(subs(Translation,{x,y,z},{-2*d1,-length_upper/2,0}));
        
    end
    
    SaveMatrix(h:h+3,:) = TMatrix;
    SaveOrig(h:h+3,:)   = origOld;   
    origNew             = TMatrix*orig;  
    xNew                = TMatrix*xVec;
    yNew                = TMatrix*yVec;
    zNew                = TMatrix*zVec;    
    j                   = j + 4; 
    h                   = h + 4;
    
    figure(1)
    plot3([origNew(1) xNew(1)],[origNew(2) xNew(2)],[origNew(3) xNew(3)],xVectorColorLine,'LineWidth',VectorLineWidth);
    hold on
    plot3([origNew(1) yNew(1)],[origNew(2) yNew(2)],[origNew(3) yNew(3)],yVectorColorLine,'LineWidth',VectorLineWidth);
    plot3([origNew(1) zNew(1)],[origNew(2) zNew(2)],[origNew(3) zNew(3)],zVectorColorLine,'LineWidth',VectorLineWidth);
    plot3([origOld(1) origNew(1)],[origOld(2) origNew(2)],[origOld(3) origNew(3)],linkColor,'LineWidth',linkSize);
    grid on
    
%     axis([xmin xmax ymin ymax zmin zmax])
    axis('equal')
    view([viewX,viewY,viewZ]);
    origOld = origNew;
    xlabel ' x '
    ylabel ' y '
    zlabel ' z '
   
end

end


%% Animation

if (animation == true)

Avi = 0;
if Avi == 1
    writerObj = VideoWriter('StewartGoughPlatformRotationTranslationNew.avi');
    open(writerObj);
end

t                     = 0:0.1:10;
wn_yaw                = 1;
wn_pitch              = 3;
wn_roll               = 1.5;
yaw                   = 8*pi/180*sin(1*t);
pitch                 = 10*pi/180*sin(2*t);
roll                  = 12*pi/180*sin(1.5*t);
center_x              = 0;
center_y              = 0;
center_z              = 60;
home_height           = 40;
center_to_frame3_dist = home_height - center_z;
sway_new              = 6*sin(1*t);
surge_new             = 4*cos(1*t);
heave_new             = 5*sin(1*t);

length_upper = 50;
length_lower = length_upper*2;
d1           = sqrt(length_upper^2 - (length_upper/2)^2)/2;
d2           = sqrt(length_lower^2 - (length_lower/2)^2)/2;

% - Platfrom points
P_front_left_lower_x     = -length_upper;
P_front_left_lower_y     = d2;
P_front_right_lower_x    = length_upper;
P_front_right_lower_y    = d2;
P_back_lower_y           = -d2;
P_front_left_lower       = [P_front_left_lower_x;P_front_left_lower_y;0];
P_front_right_lower      = [P_front_right_lower_x;P_front_right_lower_y;0];
P_back_lower             = [0;P_back_lower_y;0];

La_chassis = 30;

LocalToActuatorBase_1   = double(subs(Translation,{x,y,z},{P_front_left_lower(1),P_front_left_lower(2),P_front_left_lower(3)}));
LocalToActuatorBase_2   = double(subs(Translation,{x,y,z},{P_front_left_lower(1),P_front_left_lower(2),P_front_left_lower(3)}));
LocalToActuatorBase_3   = double(subs(Translation,{x,y,z},{P_back_lower(1),P_back_lower(2),P_back_lower(3)}));
LocalToActuatorBase_4   = double(subs(Translation,{x,y,z},{P_back_lower(1),P_back_lower(2),P_back_lower(3)}));
LocalToActuatorBase_5   = double(subs(Translation,{x,y,z},{P_front_right_lower(1),P_front_right_lower(2),P_front_right_lower(3)}));
LocalToActuatorBase_6   = double(subs(Translation,{x,y,z},{P_front_right_lower(1),P_front_right_lower(2),P_front_right_lower(3)}));

j = 1;

Amax          = length(t);
iteration     = 1;
k = 1;

for i = 1:Amax
   
    LocalToCenterNew(k:k+3,:)   = double(subs(LocalToCenter,{rotation_center_x,rotation_center_y,rotation_center_z,sway,surge,heave},{center_x,center_y,center_z,sway_new(i),surge_new(i),heave_new(i)}));
    CenterToVehicleNew(k:k+3,:)  = double(subs(CenterToVehicle2,{theta_yaw,theta_pitch,theta_roll,l2},{yaw(i),pitch(i),roll(i),center_to_frame3_dist}));
    LocalToVehicleNew(k:k+3,:)   = LocalToCenterNew(k:k+3,:)*CenterToVehicleNew(k:k+3,:);
    
    P_front_upper_prime      = LocalToVehicleNew(k:k+3,:)*double(subs(Translation,{x,y,z},{-d1,0,0}));
    P_front_upper            = P_front_upper_prime(1:3,4);
    P_back_left_upper_prime  = LocalToVehicleNew(k:k+3,:)*double(subs(Translation,{x,y,z},{d1,length_upper/2,0}));
    P_back_left_upper        = P_back_left_upper_prime(1:3,4);
    P_back_right_upper_prime = LocalToVehicleNew(k:k+3,:)*double(subs(Translation,{x,y,z},{d1,-length_upper/2,0}));
    P_back_right_upper       = P_back_right_upper_prime(1:3,4);
    
    La1(i) = norm(P_front_upper - P_front_left_lower);
    La2(i) = norm(P_back_left_upper - P_front_left_lower);
    La3(i) = norm(P_back_left_upper - P_back_lower);
    La4(i) = norm(P_back_right_upper - P_back_lower);
    La5(i) = norm(P_back_right_upper - P_front_right_lower);
    La6(i) = norm(P_front_upper - P_front_right_lower);
    
    diff_xa1 = P_front_left_lower(1) - P_front_upper(1);
    diff_ya1 = P_front_left_lower(2) - P_front_upper(2);
    diff_za1 = P_front_left_lower(3) - P_front_upper(3);
    theta_a1 = atan(diff_ya1/diff_xa1);
    theta_b1 = atan(abs(diff_za1)/norm([diff_xa1 diff_ya1]));

    diff_xa2 = P_front_left_lower(1) - P_back_left_upper(1);
    diff_ya2 = P_front_left_lower(2) - P_back_left_upper(2);
    diff_za2 = P_front_left_lower(3) - P_back_left_upper(3);
    theta_a2 = atan(diff_ya2/diff_xa2);
    theta_b2 = atan(abs(diff_za2)/norm([diff_xa2 diff_ya2]));

    diff_xa3 = P_back_lower(1) - P_back_left_upper(1);
    diff_ya3 = P_back_lower(2) - P_back_left_upper(2);
    diff_za3 = P_back_lower(3) - P_back_left_upper(3);
    theta_a3 = pi+atan(diff_ya3/diff_xa3);
    theta_b3 = atan(abs(diff_za3)/norm([diff_xa3 diff_ya3]));

    diff_xa4 = P_back_lower(1) - P_back_right_upper(1);
    diff_ya4 = P_back_lower(2) - P_back_right_upper(2);
    diff_za4 = P_back_lower(3) - P_back_right_upper(3);
    theta_a4 = atan(diff_ya4/diff_xa4);
    theta_b4 = atan(abs(diff_za4)/norm([diff_xa4 diff_ya4]));

    diff_xa5 = P_front_right_lower(1) - P_back_right_upper(1);
    diff_ya5 = P_front_right_lower(2) - P_back_right_upper(2);
    diff_za5 = P_front_right_lower(3) - P_back_right_upper(3);
    theta_a5 = pi+atan(diff_ya5/diff_xa5);
    theta_b5 = atan(abs(diff_za5)/norm([diff_xa5 diff_ya5]));

    diff_xa6 = P_front_right_lower(1) - P_front_upper(1);
    diff_ya6 = P_front_right_lower(2) - P_front_upper(2);
    diff_za6 = P_front_right_lower(3) - P_front_upper(3);
    theta_a6 = pi+atan(diff_ya6/diff_xa6);
    theta_b6 = atan(abs(diff_za6)/norm([diff_xa6 diff_ya6]));
    
    ActuatorBaseToChassis_1(k:k+3,:) = [double(subs(Rz,theta,theta_a1))*double(subs(Ry,theta,-theta_b1)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
    ChassisToStrokeTip_1(k:k+3,:)    = double(subs(Translation,{x,y,z},{La1(i)-La_chassis,0,0}));

    ActuatorBaseToChassis_2(k:k+3,:) = [double(subs(Rz,theta,theta_a2))*double(subs(Ry,theta,-theta_b2)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
    ChassisToStrokeTip_2(k:k+3,:)    = double(subs(Translation,{x,y,z},{La2(i)-La_chassis,0,0}));

    ActuatorBaseToChassis_3(k:k+3,:) = [double(subs(Rz,theta,theta_a3))*double(subs(Ry,theta,-theta_b3)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
    ChassisToStrokeTip_3(k:k+3,:)    = double(subs(Translation,{x,y,z},{La3(i)-La_chassis,0,0}));

    ActuatorBaseToChassis_4(k:k+3,:) = [double(subs(Rz,theta,theta_a4))*double(subs(Ry,theta,-theta_b4)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
    ChassisToStrokeTip_4(k:k+3,:)    = double(subs(Translation,{x,y,z},{La4(i)-La_chassis,0,0}));

    ActuatorBaseToChassis_5(k:k+3,:) = [double(subs(Rz,theta,theta_a5))*double(subs(Ry,theta,-theta_b5)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
    ChassisToStrokeTip_5(k:k+3,:)    = double(subs(Translation,{x,y,z},{La5(i)-La_chassis,0,0}));

    ActuatorBaseToChassis_6(k:k+3,:) = [double(subs(Rz,theta,theta_a6))*double(subs(Ry,theta,-theta_b6)) [0;0;0];0 0 0 1]*double(subs(Translation,{x,y,z},{La_chassis,0,0}));
    ChassisToStrokeTip_6(k:k+3,:)    = double(subs(Translation,{x,y,z},{La6(i)-La_chassis,0,0}));
   
    k = k + 4;
end

figure(10)
plot(t,La1-La_chassis,t,La2-La_chassis,t,La3-La_chassis,t,La4-La_chassis,t,La5-La_chassis,t,La6-La_chassis)
title 'Stroke Length Profile with Center of Rotation at (Home Height+20)'
ylabel ' Stroke Length'
xlabel ' Time (Seconds)'
legend('La1','La2','La3','La4','La5','La6')

q = 1;
four_by_four_mat = 4;
animate = true;
if animate == true
while iteration < Amax + 1

    linkSize       = 1;
    linkColor      = 'k';
    Matrix         = [eye(4);LocalToCenterNew(q:q+3,:);CenterToVehicleNew(q:q+3,:)];  % Full link descriptions are saved in this matrix.
    TMatrix        = eye(4);    
    origOld        = orig;
    
    for i = 1:(length(Matrix)/four_by_four_mat + Extra)
   
        if ( i <= length(Matrix)/four_by_four_mat )

            for k = 1:i            

                if (i - k == 1)
                    TMatrix = TMatrix*Matrix(j:j+3,:);
                end

            end
        % Let's plot the additional links/frames, if they are any    
        % - Actuator 1
        elseif (i == length(Matrix)/four_by_four_mat + 1 )   

            TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_1;
            origOld       = [P_front_left_lower;1];

        elseif (i == length(Matrix)/four_by_four_mat + 2 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_1(q:q+3,:);
            linkSize      = 4;
            linkColor     = 'b';

        elseif (i == length(Matrix)/four_by_four_mat + 3 )

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_1(q:q+3,:);
            linkSize      = 2;
            linkColor     = 'r';

        % - Actuator 2
        elseif (i == length(Matrix)/four_by_four_mat + 4 )  

            TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_2;
            origOld       = [P_front_left_lower;1];

        elseif (i == length(Matrix)/four_by_four_mat + 5 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_2(q:q+3,:);
            linkSize      = 4;
            linkColor     = 'b';

        elseif (i == length(Matrix)/four_by_four_mat + 6 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_2(q:q+3,:);
            linkSize      = 2;
            linkColor     = 'r';

        % - Actuator 3
        elseif (i == length(Matrix)/four_by_four_mat + 7 )  

            TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_3;
            origOld       = [P_back_lower;1];

        elseif (i == length(Matrix)/four_by_four_mat + 8 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_3(q:q+3,:);
            linkSize      = 4;
            linkColor     = 'b';

        elseif (i == length(Matrix)/four_by_four_mat + 9 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_3(q:q+3,:);
            linkSize      = 2;
            linkColor     = 'r';

        % - Actuator 4
        elseif (i == length(Matrix)/four_by_four_mat + 10 )  

            TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_4;
            origOld       = [P_back_lower;1];

        elseif (i == length(Matrix)/four_by_four_mat + 11 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_4(q:q+3,:);
            linkSize      = 4;
            linkColor     = 'b';

        elseif (i == length(Matrix)/four_by_four_mat + 12 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_4(q:q+3,:);
            linkSize      = 2;
            linkColor     = 'r';

        % - Actuator 5
        elseif (i == length(Matrix)/four_by_four_mat + 13 )  

            TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_5;
            origOld       = [P_front_right_lower;1];

        elseif (i == length(Matrix)/four_by_four_mat + 14 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_5(q:q+3,:);
            linkSize      = 4;
            linkColor     = 'b';

        elseif (i == length(Matrix)/four_by_four_mat + 15 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_5(q:q+3,:);
            linkSize      = 2;
            linkColor     = 'r';

        % - Actuator 6
        elseif (i == length(Matrix)/four_by_four_mat + 16 )  

            TMatrix       = SaveMatrix( 1:4, : ) * LocalToActuatorBase_6;
            origOld       = [P_front_right_lower;1];

        elseif (i == length(Matrix)/four_by_four_mat + 17 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ActuatorBaseToChassis_6(q:q+3,:);
            linkSize      = 4;
            linkColor     = 'b';

        elseif (i == length(Matrix)/four_by_four_mat + 18 ) 

            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * ChassisToStrokeTip_6(q:q+3,:);
            linkSize      = 2;
            linkColor     = 'r';

        % - Upper Triangle
        elseif (i == length(Matrix)/four_by_four_mat + 19 ) 
            TMatrix       = SaveMatrix( 1:4, : ) * LocalToVehicleNew(q:q+3,:) * double(subs(Translation,{x,y,z},{-d1,0,0}));
            orig = [0;0;0;1];

        elseif (i == length(Matrix)/four_by_four_mat + 20 ) 
            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * double(subs(Translation,{x,y,z},{d1*2,-length_upper/2,0}));
            linkSize      = 3;
            linkColor     = 'g';
            
        elseif (i == length(Matrix)/four_by_four_mat + 21 ) 
            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * double(subs(Translation,{x,y,z},{0,length_upper,0}));
            linkSize      = 3;
            linkColor     = 'g';

        elseif (i == length(Matrix)/four_by_four_mat + 22 ) 
            TMatrix       = SaveMatrix( length(SaveMatrix)-3:length(SaveMatrix) , : ) * double(subs(Translation,{x,y,z},{-2*d1,-length_upper/2,0}));
            linkSize      = 3;
            linkColor     = 'g';

        end

        SaveMatrix(h:h+3,:) = TMatrix;
        SaveOrig(h:h+3,:)   = origOld;   
        origNew             = TMatrix*orig;  
        xNew                = TMatrix*xVec;
        yNew                = TMatrix*yVec;
        zNew                = TMatrix*zVec;   
        h                   = h + 4;
        j                   = j + 4; 

        plot3([origNew(1) xNew(1)],[origNew(2) xNew(2)],[origNew(3) xNew(3)],xVectorColorLine,'LineWidth',VectorLineWidth);
        hold on
        plot3([origNew(1) yNew(1)],[origNew(2) yNew(2)],[origNew(3) yNew(3)],yVectorColorLine,'LineWidth',VectorLineWidth);
        plot3([origNew(1) zNew(1)],[origNew(2) zNew(2)],[origNew(3) zNew(3)],zVectorColorLine,'LineWidth',VectorLineWidth);
        plot3([origOld(1) origNew(1)],[origOld(2) origNew(2)],[origOld(3) origNew(3)],linkColor,'LineWidth',linkSize);
        grid on
        axis([xmin xmax ymin ymax zmin zmax])
%         axis('equal')
        view([viewX,viewY,viewZ]);
%         view(180,0);
        origOld = origNew;
    end
    
    j = 1;
    
    if Avi == 1
        frame1 = getframe;
        writeVideo(writerObj,frame1);
    else
      drawnow;
    end
    
    hold off
    
    iteration = iteration + 1;
    q = q + 4;
    
end

if Avi == 1
close(writerObj);
end 

end

end
