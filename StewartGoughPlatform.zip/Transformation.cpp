#include "math.h"
#include "matrixOperation.h"
#include <stdlib.h>
#include "Transformation.h"
#include <iomanip>  

const long double pi			 = 3.141592653589793238L;

float center_of_rotation_x		 = 0.0;
float center_of_rotation_y		 = 0.0;
float center_of_rotation_z		 = 60.0;
float home_height				 = 40.0;
float center_to_frame3_dist	 = home_height - center_of_rotation_z;
float length_upper				 = 50.0;
float length_lower				 = 2.0*length_upper;
float d1						 = sqrt(length_upper*length_upper - length_upper*length_upper/4.0) / 2.0;
float d2					     = sqrt(length_lower*length_lower - length_upper*length_upper) / 2.0;
float P_front_left_lower[3][1]  = { -length_upper, d2, 0.0 };
float P_back_lower[3][1]        = { 0.0, -d2, 0.0 };
float P_front_right_lower[3][1] = { length_upper, d2, 0.0 };
float LocalToV[4][4];
float actuator_length_mat[6][1], actuator_angle_mat[6][2];

//extern output transformation;
extern angle_output angle_transformation;
extern output base_transformation[6];
extern smaller_output actuator_transformation[6];

void Translation_Homogeneous(float x, float y, float z, float *T)
{
	int rol = 4, col = 4;

	identityMat(4,T,1);

	*(T + (0 * rol) + 3) = x;
	*(T + (1 * rol) + 3) = y;
	*(T + (2 * rol) + 3) = z;
}

void Rotation_Homogeneous(float angle, Rotation rotation_axis, float *R)
{
	int rol = 4, col = 4;

	identityMat(4,R,1);
	
	if ( rotation_axis == Rx )
	{
		*(R + (1 * rol) + 1) = *(R + (2 * rol) + 2) = cos(angle);
		*(R + (1 * rol) + 2) = -sin(angle);
		*(R + (2 * rol) + 1) = sin(angle);
	}
	else if ( rotation_axis == Ry )
	{
		*(R + (0 * rol) + 0) = *(R + (2 * rol) + 2) = cos(angle);
		*(R + (0 * rol) + 2) = sin(angle);
		*(R + (2 * rol) + 0) = -sin(angle);
	}
	else if ( rotation_axis == Rz )
	{
		*(R + (0 * rol) + 0) = *(R + (1 * rol) + 1) = cos(angle);
		*(R + (0 * rol) + 1) = -sin(angle);
		*(R + (1 * rol) + 0) = sin(angle);
	}

}

void FindRotationAxisAndAngle(float *input_matrix, float *output_matrix) // Decided not to use this, it only works for composite of two rotations
{
	float v[3][1], norm_of_v, c1, s1;
	static int print = 0;
	v[0][0] = *(input_matrix + (1*4) + 2) - *(input_matrix + (2*4) + 0);
	v[1][0] = *(input_matrix + (2*4) + 0) - *(input_matrix + (0*4) + 2);
	v[2][0] = *(input_matrix + (0*4) + 1) - *(input_matrix + (1*4) + 0);



	norm_of_v			 = vector_norm(v[0],1);
	*(output_matrix)     = v[0][0]/norm_of_v;
	*(output_matrix + 1) = v[1][0]/norm_of_v;
	*(output_matrix + 2) = v[2][0]/norm_of_v;
	
	
	c1 = ( *(input_matrix + (0*4) + 0) + *(input_matrix + (1*4) + 1) + *(input_matrix + (2*4) + 2) - 1.0 ) / 2.0;
	s1 = sqrt(1.0 - c1*c1);

	if ( *(input_matrix + (1*4) + 0) > 0 ) 
	{
		if ( s1 < 0 )
		{
			s1 = - s1;
		}
	}
	else
	{
		if ( s1 > 0 )
		{
			s1 = -s1;
		}
	}
	*(output_matrix + 3) = asin(s1);

	if ( print )
	{


				printf("%f ",*(output_matrix+3));

			printf("\r\n");

		//printf("angle: %f, %f\r\n",*(output_matrix + 3),c1);
		print = 0;
	}

}

void CalculateActuatorParameters(void)
{
	float P_front_upper[3][1], P_back_left_upper[3][1], P_back_right_upper[3][1];
	float p1[4][4], Tr[4][4], p2[4][4], p3[4][4];
	float pa1[3][1], pa2[3][1], pa3[3][1], pa4[3][1], pa5[3][1], pa6[3][1];
	float *ptr[6], pa_prime[2][1];
	int i, j;
	static int print = 0;

	Translation_Homogeneous(-d1,0.0,0.0,Tr[0]);
	MatrixMultiply(LocalToV[0],4,4,Tr[0],4,4,p1[0]);

	Translation_Homogeneous(d1,length_upper/2.0,0.0,Tr[0]);
	MatrixMultiply(LocalToV[0],4,4,Tr[0],4,4,p2[0]);
	
	Translation_Homogeneous(d1,-length_upper/2.0,0.0,Tr[0]);
	MatrixMultiply(LocalToV[0],4,4,Tr[0],4,4,p3[0]);

	for ( i = 0; i < 3; i++ )
	{
		P_front_upper[i][0]      = p1[i][3];
		P_back_left_upper[i][0]  = p2[i][3];
		P_back_right_upper[i][0] = p3[i][3];
	}
	
	MatrixSubtract(P_front_upper[0],P_front_left_lower[0],3,1,pa1[0]);
	MatrixSubtract(P_back_left_upper[0],P_front_left_lower[0],3,1,pa2[0]);
	MatrixSubtract(P_back_left_upper[0],P_back_lower[0],3,1,pa3[0]);
	MatrixSubtract(P_back_right_upper[0],P_back_lower[0],3,1,pa4[0]);
	MatrixSubtract(P_back_right_upper[0],P_front_right_lower[0],3,1,pa5[0]);
	MatrixSubtract(P_front_upper[0],P_front_right_lower[0],3,1,pa6[0]);

	ptr[0] = pa1[0];
	ptr[1] = pa2[0];
	ptr[2] = pa3[0];
	ptr[3] = pa4[0];
	ptr[4] = pa5[0];
	ptr[5] = pa6[0];

	for ( j = 0; j < 6; j++ )
	{
		//*( actuator_length + (j * 6) + 0 ) = vector_norm(ptr[j],1);
		actuator_length_mat[j][0] = vector_norm(ptr[j],1);
		if ( ( j == 2 ) || ( j == 4 ) || ( j == 5 ) )
		{
			//*( actuator_angle + ( j * 6 ) + 0 ) = pi + atan( (*(ptr[j]+1)) / (*(ptr[j])) );
			actuator_angle_mat[j][0] = pi + atan( (*(ptr[j]+1)) / (*(ptr[j])) );
		}
		else
			{
			//*( actuator_angle + ( j * 6 ) + 0 ) = atan( (*(ptr[j]+1)) / (*(ptr[j])) );
			actuator_angle_mat[j][0] = atan( (*(ptr[j]+1)) / (*(ptr[j])) );
		}

		pa_prime[0][0] = *(ptr[j]);
		pa_prime[1][0] = *(ptr[j]+1);
		//*( actuator_angle + ( j * 6 ) + 1 ) = atan( fabs(*(ptr[j]+2)) / vector_norm(pa_prime[0],1) );
		actuator_angle_mat[j][1] = atan( fabs(*(ptr[j]+2)) / sqrt(pa_prime[0][0]*pa_prime[0][0] + pa_prime[1][0]*pa_prime[1][0]) );
	}

	if ( print )
	{
		printf("Stage 1\r\n");
	for ( int k = 0; k < 6; k++ )
	{
		for ( int j = 0; j < 2; j++ )
		{
			printf("%f ",actuator_angle_mat[k][j]);
		}
		printf("\r\n");
	}
	print = 0;
	}

}

void LocalToBaseAndActuator(float actuator_chassis)
{
	float *base_coordinates_ptr[6], *LtoBase_ptr[6];
	float LtoBase1[4][4], LtoBase2[4][4], LtoBase3[4][4], LtoBase4[4][4], LtoBase5[4][4], LtoBase6[4][4];
	float Mat1[4][4], T1[4][4], R1[4][4], R2[4][4];
	float RotationAxisAndAngle[4][1];
	int i;
	static int print = 0;

	CalculateActuatorParameters();

	base_coordinates_ptr[0] = P_front_left_lower[0];
	base_coordinates_ptr[1] = P_front_left_lower[0];
	base_coordinates_ptr[2] = P_back_lower[0];
	base_coordinates_ptr[3] = P_back_lower[0];
	base_coordinates_ptr[4] = P_front_right_lower[0];
	base_coordinates_ptr[5] = P_front_right_lower[0];

	LtoBase_ptr[0] = LtoBase1[0];
	LtoBase_ptr[1] = LtoBase2[0];
	LtoBase_ptr[2] = LtoBase3[0];
	LtoBase_ptr[3] = LtoBase4[0];
	LtoBase_ptr[4] = LtoBase5[0];
	LtoBase_ptr[5] = LtoBase6[0];

	for ( i = 0; i < 6; i++ )
	{
		Translation_Homogeneous( *( base_coordinates_ptr[i] ), *( base_coordinates_ptr[i] + 1 ), *( base_coordinates_ptr[i] + 2 ), T1[0]);
		Rotation_Homogeneous( actuator_angle_mat[i][0], Rz, R1[0]);
		Rotation_Homogeneous(-actuator_angle_mat[i][1], Ry, R2[0]);
		MatrixMultiply(T1[0],4,4,R1[0],4,4,Mat1[0]);
		MatrixMultiply(Mat1[0],4,4,R2[0],4,4,LtoBase_ptr[i]);
		FindRotationAxisAndAngle(LtoBase_ptr[i],RotationAxisAndAngle[0]);

		base_transformation[i].P[0][0]				  = *(base_coordinates_ptr[i] + 0);
		base_transformation[i].P[1][0]				  = *(base_coordinates_ptr[i] + 1);
		base_transformation[i].P[2][0]				  = *(base_coordinates_ptr[i] + 2);
		base_transformation[i].angle_of_rotation[0][0]      = actuator_angle_mat[i][0];
		base_transformation[i].angle_of_rotation[1][0]      = actuator_angle_mat[i][1];
		// actuator rod has different coordinates, but rotation components remain unchanged.
		actuator_transformation[i].stroke             = actuator_length_mat[i][0]-actuator_chassis;
		
		if ( print )
		{
			printf("Stage 1\r\n");
	/*		for ( int k = 0; k < 4; k++ )
			{
				for(int j = 0 ; j < 4; j++ )
				{*/
					printf("%f ",actuator_angle_mat[i][1]);
					
				/*}
				printf("\r\n");
			}*/
			printf("\r\n");
		}
	
	}
	print = 0;
}


void LocalToVehicle(float sway, float surge, float heave, float yaw, float pitch, float roll)
{
	float T1[4][4], T2[4][4], Rotation_y[4][4], Rotation_z1[4][4], Rotation_z2[4][4], Rotation_z3[4][4], Rotation_x1[4][4], theta[3][1], Tr2[4][4];
	float Mat1[4][4], Mat2[4][4], Mat3[4][4], Mat4[4][4], Mat5[4][4], Mat6[4][4], Mat7[4][4], RotationAxisAndAngle[4][1];
	static int print = 0;
	SolveAngleKinematics(theta[0],yaw,pitch,roll);
	Translation_Homogeneous(center_of_rotation_x,center_of_rotation_y,center_of_rotation_z,T1[0]);
	Translation_Homogeneous(sway,surge,heave,T2[0]);
	Rotation_Homogeneous(pi/2.0,Ry,Rotation_y[0]);
	Rotation_Homogeneous(theta[0][0],Rz,Rotation_z1[0]);
	Rotation_Homogeneous(-pi/2.0,Rx,Rotation_x1[0]);
	Rotation_Homogeneous(theta[1][0],Rz,Rotation_z2[0]);
	Translation_Homogeneous(-center_to_frame3_dist,0.0,0.0,Tr2[0]);
	Rotation_Homogeneous(theta[2][0],Rz,Rotation_z3[0]);

	MatrixMultiply(T1[0],4,4,T2[0],4,4,Mat1[0]);  // LocalToT1 * T1ToT2
	MatrixMultiply(Mat1[0],4,4,Rotation_y[0],4,4,Mat2[0]);  // LocalToT1 * T1ToT2 * Ry(90)
	MatrixMultiply(Mat2[0],4,4,Rotation_z1[0],4,4,Mat3[0]);  // LocalToT1 * T1ToT2 * Ry(90) * Rz(theta1)
	MatrixMultiply(Mat3[0],4,4,Rotation_x1[0],4,4,Mat4[0]);  // LocalToT1 * T1ToT2 * Ry(90) * Rz(theta1) * Rx(-90)
	MatrixMultiply(Mat4[0],4,4,Rotation_z2[0],4,4,Mat5[0]);  // LocalToT1 * T1ToT2 * Ry(90) * Rz(theta1) * Rx(-90) * Rz(theta2)
	MatrixMultiply(Mat5[0],4,4,Tr2[0],4,4,Mat6[0]);  // LocalToT1 * T1ToT2 * Ry(90) * Rz(theta1) * Rx(-90) * Rz(theta2) * FrameR2ToFrameR3
	MatrixMultiply(Mat6[0],4,4,Rotation_y[0],4,4,Mat7[0]);  // LocalToT1 * T1ToT2 * Ry(90) * Rz(theta1) * Rx(-90) * Rz(theta2) * FrameR2ToFrameR3 * Ry(90)
	MatrixMultiply(Mat7[0],4,4,Rotation_z3[0],4,4,LocalToV[0]);  // LocalToT1 * T1ToT2 * Ry(90) * Rz(theta1) * Rx(-90) * Rz(theta2) * FrameR2ToFrameR3 * Ry(90) * Rz(theta3)
	
	

	//FindRotationAxisAndAngle(LocalToV[0],RotationAxisAndAngle[0]);
	
	angle_transformation.a[0][0]				  = theta[0][0];
	angle_transformation.a[1][0]				  = theta[1][0];
	angle_transformation.a[2][0]				  = theta[2][0];
}

void SolveAngleKinematics(float *angle_kinematics_solution, float yaw, float pitch, float roll)
{
	float Ryaw[4][4], Rpitch[4][4], Rroll[4][4], R1[4][4], Rzyx_euler[4][4], LtoEuler[4][4];
	float Lv[4][4] = {{0.0, 1.0, 0.0, 0.0},
					  {1.0, 0.0, 0.0, 0.0},
					  {0.0, 0.0, -1.0,0.0},
					  {0.0, 0.0, 0.0, 1.0}};
	static int print = 0;
	Rotation_Homogeneous(yaw,Rz,Ryaw[0]);
	Rotation_Homogeneous(pitch,Ry,Rpitch[0]);
	Rotation_Homogeneous(roll,Rx,Rroll[0]);

	

	MatrixMultiply(Ryaw[0],4,4,Rpitch[0],4,4,R1[0]);
	MatrixMultiply(R1[0],4,4,Rroll[0],4,4,Rzyx_euler[0]);
	MatrixMultiply(Lv[0],4,4,Rzyx_euler[0],4,4,LtoEuler[0]);

	*(angle_kinematics_solution)     = atan(-LtoEuler[1][2]/LtoEuler[2][2]);
	*(angle_kinematics_solution + 1) = asin(-LtoEuler[0][2]);
	*(angle_kinematics_solution + 2) = atan(LtoEuler[0][0]/LtoEuler[0][1]);

	if ( print )
	{
	for ( int i = 0; i < 3; i++ )
	{

			printf("%f ",*(angle_kinematics_solution + i));
		printf("\r\n");
	}
	print = 0;
	}
}