#ifndef _Transformation_h
#define _Transformation

extern float d1;
extern float length_upper;
extern float center_of_rotation_x;
extern float center_of_rotation_y;
extern float center_of_rotation_z;
extern float center_to_frame3_dist;

typedef enum {Rx, Ry, Rz} Rotation;

typedef struct 
{
    float P[3][1];
	float angle_of_rotation[2][1];
}output;

typedef struct
{
	float stroke;
}smaller_output;

typedef struct
{
	float a[3][1];
}angle_output;

void Translation_Homogeneous(float x, float y, float z, float *T);

void Rotation_Homogeneous(float angle, Rotation rotation_axis, float *R);

void SolveAngleKinematics(float *angle_kinematics_solution, float yaw, float pitch, float roll);

void FindRotationAxisAndAngle(float *input_matrix, float *output_matrix);

void CalculateActuatorParameters(void);

void LocalToBaseAndActuator(float actuator_chassis);

void LocalToVehicle(float sway, float surge, float heave, float yaw, float pitch, float roll);

#endif