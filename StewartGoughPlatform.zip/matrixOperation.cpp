#include "math.h"
#include "matrixOperation.h"
#include <stdlib.h>

void MatrixAdd(float *mat_ptr1, float *mat_ptr2, int row, int col, float *mat_result)
{
	int i, j;
	clearMatrix(mat_result,row,col);
	for( i = 0; i < row; i++ )
	{
		for( j = 0; j < col; j++ )
		{
			*( mat_result + ( i * col ) + j ) = *( mat_ptr1 + ( i * col ) + j ) + *( mat_ptr2 + ( i * col ) + j );
		}
	}

}

void MatrixSubtract(float *mat_ptr1, float *mat_ptr2, int row, int col, float *mat_result)
{
	int i, j;
	clearMatrix(mat_result,row,col);
	for( i = 0; i < row; i++ )
	{
		for( j = 0; j < col; j++ )
		{
			*( mat_result + ( i * col ) + j ) = *( mat_ptr1 + ( i * col ) + j ) - *( mat_ptr2 + ( i * col ) + j );
		}
	}
}

void MatrixMultiply(float *mat_ptr1, int row1, int col1, float *mat_ptr2, int row2, int col2, float *mat_result)
{
	int i, j, k;
	clearMatrix(mat_result,row1,col2);
	if( col1 == row2 )
	{
		for( i = 0; i < row1; i++ )
		{
			for( j = 0; j < col2; j++ )
			{
				for( k = 0; k < col1; k++ )
				{
					*( mat_result + ( i * col2 ) + j )  +=  ( *( mat_ptr1 + ( i * col1 ) + k ) ) * ( *( mat_ptr2 + ( k * col2 ) + j ) );
					
				}
			}
		}
	}
}


static void determinant(float *mat, int size, float *det_result)
{   // Find the determinant of a matrix using LU decomposition via Crout's algorithm.
	const int length = 10;  // This is a way to pre-allocate sufficient array size. Reconfigure this size if the square matrix is bigger than 10 x 10.
	float L[10][10];       // Don't forget to change the sizes of matrices here too, they should be the same as length.
	float U[10][10];
	float sum = 0;
	int i, j, l, p;
	//float det = 1;

	clearMatrix(U[0],10,10);
	identityMat(10,L[0],1);

	*det_result = 1;
	for ( j = 0; j < size; j++ )
	{	
		for ( i = 0; i < size; i++ )
		{			
			sum = 0;			// clear sum
			if ( j >= i )
			{
				for ( l = 0; l <= ( i - 1 ); l++ )
				{
					sum += ( *( L[0] + ( i * length ) + l) ) * ( *( U[0] + ( l * length ) + j ) );
				}
				*( U[0] + ( i * length ) + j ) = *( mat + ( i * size ) + j ) - sum;   // calculate elements of upper triangle matrix
			}
			else if ( i > j )
			{ 
				for ( p = 0; p <= ( j - 1 ); p++ )
				{
					sum += ( *( L[0] + ( i * length ) + p ) ) * ( *( U[0] + ( p * length ) + j ) );
				}
				if ( *( U[0] + ( j * length ) + j ) != 0 )
				{
					*( L[0] + ( i * length ) + j ) = ( *( mat + ( i * size ) + j ) - sum ) / ( *( U[0] + ( j * length ) + j ) );//( U[j][j] );	 // calculate elements of lower triangle matrix
				}
				//else
				//{
					//printf("Matrix is singular");
					//return det;
				//}
			}
		}
		*det_result *= *( U[0] + (j *length ) + j );
	}
	//return det;
}


static void adjoint(float *mat, int size, float *mat_result) // This function takes in a square matrix, matrix roll or column size, and the resulting matrix.
{
	int h, i, j, k, l = 0, p = 0;
	float minorElementMat[100], cmat[100];   // let's initialize an array of 100 elements which is equivalent to a 10x10 matrix, simply increase this if larger matrix dimension is desired.
	float det;
	clearMatrix(mat_result,size,size);
	clearMatrix(minorElementMat,10,10);
	clearMatrix(cmat,10,10);
	for ( h = 0; h < size; h++ )
	{
		for ( k = 0; k < size; k++ )
		{
			for ( i = 0; i < size; i++ )
			{
				for ( j = 0; j < size; j++ )
				{
					if ( ( i != h ) && ( j != k ) )
					{
						*( minorElementMat + l ) = *( mat + ( i * size ) + j ); // Find the elements of the matrix that 
						l++;													// will be used to calculate the elements of the minor matrix.
					}
				}
			}
			l = 0;
			determinant(minorElementMat,size-1,&det);  // elements of minor matrix
			*( cmat + p ) = pow( -1.0, ((h+1)+(k+1)) ) * det;  // cofactor matrix
			p++;
		}
	}
	transpose(cmat,size,size,mat_result);  // adjoint of a matrix is the transpose of the cofactor matrix.
}

void transpose(float *mat, int row, int col, float *mat_result)  // This function takes in a matrix, its roll and column, and the resultant matrix to be stored in.
{
	int i, j;
	clearMatrix(mat_result,col,row);
	for ( i = 0; i < col; i++ )
	{
		for ( j = 0; j < row; j++ )
		{
			*( mat_result + ( i * row ) + j ) = *(mat + ( j * col ) + i );
		}
	}
}

void inverse(float *mat, int size, float *mat_result) // this function takes in a matrix, its roll/size, and the resultant matrix.
{
	clearMatrix(mat_result,size,size);
	if ( size > 1)
	{
	int i, j;
	float det;
	
	float adjMat[100];
	determinant(mat,size, &det);
	adjoint(mat,size,adjMat);
	for ( i = 0; i < size; i++ )
	{
		for ( j = 0; j < size; j++ )
		{
			*( mat_result + ( i * size ) + j ) = *( adjMat + ( i * size ) + j ) / det; // Inverse of the matrix = adj(mat)/det(mat)
		}
	}
	}
	else
	{
		*mat_result = 1.0 / ( *mat);
	}
}

void identityMat(int size, float *mat_result, float constant)
{
	int i,j;
	clearMatrix(mat_result,size,size);
	for ( i = 0; i < size; i++ )
	{
		for ( j = 0; j < size; j++)
		{
			if ( i == j )
			{
				*( mat_result + ( i * size ) + j ) = 1*constant;
			}
			else
			{
				*( mat_result + ( i * size ) + j ) = 0;
			}
		}
	}
}

void clearMatrix(float *mat, int row, int col)
{
	int i, j;
	for( i = 0; i < row; i++ )
	{
		for( j = 0; j < col; j++ )
		{
			*( mat + ( i * col ) + j ) = 0;
		}
	}
}

float dot(float *vec_ptr1, float *vec_ptr2, int vector_length)
{

	int i;
	float result = 0;

	for ( i = 0; i < vector_length; i++ )
	{
		result += (*(vec_ptr1+i)) * (*(vec_ptr2+i));
	}

	return result;

}

void vector_cross(float *v1, float *v2, float *v_result)
{

	*(v_result) = (*(v1+1))*(*(v2+2)) - (*(v1+2))*(*(v2+1));
	*(v_result+1) = (*(v1+2))*(*(v2)) - (*(v1))*(*(v2+2));
	*(v_result+2) = (*(v1))*(*(v2+1)) - (*(v1+1))*(*(v2));

}

float vector_norm(float *vin, int power)
{
	if ( power < 2 )
	{
		return sqrt( (*vin)*(*vin) + (*(vin+1))*(*(vin+1)) + (*(vin+2))*(*(vin+2)));
	}
	else
	{
		return (*vin)*(*vin) + (*(vin+1))*(*(vin+1)) + (*(vin+2))*(*(vin+2));
	}

}

void quat_vector(float *q, float *result)
{
	int i;
	float vector[3][1];
	for ( i = 0; i < 3; i++ )
	{
		*(result+i) = *(q+1+i);
	}
	
}

void QuaternionOperator(float *q, float *v, float *result)
{

	float mat1[3][1];
	float mat2[3][1];
	float mat3[3][1];
	float matA[3][1];
	float matB[3][1];
	float cross_mat[3][1];
	float c1;
	float c2;
	float c3;
	float qvec[3][1];

	quat_vector(q,qvec[0]);
	c1 = (*(q))*(*(q)) - vector_norm(qvec[0],2);  // qo^2-|q_vec|^2
	MatrixMultiply(v,3,1,&c1,1,1,mat1[0]);				 // (qo^2-|q_vec|^2)*v

	c2 = 2*dot(qvec[0],v,3);                      // 2*(dot(q_vec,v))
	MatrixMultiply(qvec[0],3,1,&c2,1,1,mat2[0]);  // 2*(dot(q_vec,v))*q_vec

	c3 = 2*(*(q));                                       // 2*qo
	vector_cross(qvec[0],v,cross_mat[0]);         // (q_vec X v)
	MatrixMultiply(cross_mat[0],3,1,&c3,1,1,mat3[0]);    // 2*qo*(q_vec X v)

	MatrixAdd(mat1[0],mat2[0],3,1,matA[0]);
	MatrixAdd(matA[0],mat3[0],3,1,result);

}


void append_quat(float *real, float *vector, float *result)
{
	*result = *real;
	*(result+1) = *(vector);
	*(result+2) = *(vector+1);
	*(result+3) = *(vector+2);
}


void QuaternionMultiplication(float *p, float *q, float *result)
{

	float c1;
	float pvec[3][1];
	float qvec[3][1];
	float mat1[3][1];
	float mat2[3][1];
	float matA[3][1];
	float matB[3][1];
	float cross_mat[3][1];
	float po, qo;

	po = *(p);
	qo = *(q);

	quat_vector(p,pvec[0]);
	quat_vector(q,qvec[0]);

	c1 = po * qo  - dot(pvec[0],qvec[0],3);            // po*qo - dot(pvec,qvec)
	MatrixMultiply(qvec[0],3,1,&po,1,1,mat1[0]);       // po*qvec
	MatrixMultiply(pvec[0],3,1,&qo,1,1,mat2[0]);       // qo*pvec
	vector_cross(pvec[0],qvec[0],cross_mat[0]);					   // pvec X qvec

	MatrixAdd(mat1[0],mat2[0],3,1,matA[0]);            // po*qvec + qo*pvec
	MatrixAdd(matA[0],cross_mat[0],3,1,matB[0]);	   // po*qvec + qo*pvec + (pvec X qvec)
	append_quat(&c1,matB[0],result);                   // po*qo - dot(pvec,qvec) + po*qvec + qo*pvec + (pvec X qvec)

}
